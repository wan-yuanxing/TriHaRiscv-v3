view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 18
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_squash/clk
add wave -noupdate -label d_pending -radix hexadecimal /tb_cpu_squash/d_pending
add wave -noupdate -label d_addr -radix hexadecimal /tb_cpu_squash/d_addr
add wave -noupdate -label d_rd -radix hexadecimal /tb_cpu_squash/d_rd
add wave -noupdate -label d_wr -radix hexadecimal /tb_cpu_squash/d_wr
add wave -noupdate -label d_ack -radix hexadecimal /tb_cpu_squash/d_ack
add wave -noupdate -label d_error -radix hexadecimal /tb_cpu_squash/d_error
add wave -noupdate -label d_data -radix hexadecimal /tb_cpu_squash/d_data
add wave -noupdate -label squash -radix hexadecimal /tb_cpu_squash/squash
add wave -noupdate -label redirect -radix hexadecimal /tb_cpu_squash/redirect
add wave -noupdate -label redirect_pc -radix hexadecimal /tb_cpu_squash/redirect_pc
add wave -noupdate -label mscratch -radix hexadecimal /tb_cpu_squash/mscratch
add wave -noupdate -label mepc -radix hexadecimal /tb_cpu_squash/mepc
add wave -noupdate -label mcause -radix hexadecimal /tb_cpu_squash/mcause
add wave -noupdate -label traps -radix hexadecimal /tb_cpu_squash/traps
add wave -noupdate -label recovered -radix hexadecimal /tb_cpu_squash/recovered
add wave -noupdate -label wb_pc -radix hexadecimal /tb_cpu_squash/wb_pc
add wave -noupdate -label wb_rd -radix hexadecimal /tb_cpu_squash/wb_rd
add wave -noupdate -label wb_data -radix hexadecimal /tb_cpu_squash/wb_data
add wave -noupdate -label wb_valid -radix hexadecimal /tb_cpu_squash/wb_valid
configure wave -namecolwidth 300
configure wave -valuecolwidth 300
configure wave -rowmargin 12
configure wave -timelineunits ns
update
after 1000 {wave zoom range 1900ns 3300ns}
