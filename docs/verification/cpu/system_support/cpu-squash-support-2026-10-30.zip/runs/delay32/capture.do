onerror {quit -f -code 2}
onbreak {quit -f -code 3}
vcd file {squash.vcd}
log /tb_cpu_squash/clk
vcd add /tb_cpu_squash/clk
log /tb_cpu_squash/rst_n
vcd add /tb_cpu_squash/rst_n
log /tb_cpu_squash/i_pc
vcd add /tb_cpu_squash/i_pc
log /tb_cpu_squash/i_req
vcd add /tb_cpu_squash/i_req
log /tb_cpu_squash/i_valid
vcd add /tb_cpu_squash/i_valid
log /tb_cpu_squash/saved_i_pc
vcd add /tb_cpu_squash/saved_i_pc
log /tb_cpu_squash/d_addr
vcd add /tb_cpu_squash/d_addr
log /tb_cpu_squash/d_wr
vcd add /tb_cpu_squash/d_wr
log /tb_cpu_squash/d_rd
vcd add /tb_cpu_squash/d_rd
log /tb_cpu_squash/d_accept
vcd add /tb_cpu_squash/d_accept
log /tb_cpu_squash/d_pending
vcd add /tb_cpu_squash/d_pending
log /tb_cpu_squash/d_ack
vcd add /tb_cpu_squash/d_ack
log /tb_cpu_squash/d_error
vcd add /tb_cpu_squash/d_error
log /tb_cpu_squash/d_data
vcd add /tb_cpu_squash/d_data
log /tb_cpu_squash/saved_addr
vcd add /tb_cpu_squash/saved_addr
log /tb_cpu_squash/delay_left
vcd add /tb_cpu_squash/delay_left
log /tb_cpu_squash/squash
vcd add /tb_cpu_squash/squash
log /tb_cpu_squash/redirect
vcd add /tb_cpu_squash/redirect
log /tb_cpu_squash/redirect_pc
vcd add /tb_cpu_squash/redirect_pc
log /tb_cpu_squash/decode_pc
vcd add /tb_cpu_squash/decode_pc
log /tb_cpu_squash/decode_valid
vcd add /tb_cpu_squash/decode_valid
log /tb_cpu_squash/mscratch
vcd add /tb_cpu_squash/mscratch
log /tb_cpu_squash/mepc
vcd add /tb_cpu_squash/mepc
log /tb_cpu_squash/mcause
vcd add /tb_cpu_squash/mcause
log /tb_cpu_squash/mtval
vcd add /tb_cpu_squash/mtval
log /tb_cpu_squash/wrong_fetched
vcd add /tb_cpu_squash/wrong_fetched
log /tb_cpu_squash/wrong_decoded
vcd add /tb_cpu_squash/wrong_decoded
log /tb_cpu_squash/recovered
vcd add /tb_cpu_squash/recovered
log /tb_cpu_squash/wb_pc
vcd add /tb_cpu_squash/wb_pc
log /tb_cpu_squash/wb_rd
vcd add /tb_cpu_squash/wb_rd
log /tb_cpu_squash/wb_valid
vcd add /tb_cpu_squash/wb_valid
log /tb_cpu_squash/wb_data
vcd add /tb_cpu_squash/wb_data
log /tb_cpu_squash/traps
vcd add /tb_cpu_squash/traps
log /tb_cpu_squash/returns
vcd add /tb_cpu_squash/returns
log /tb_cpu_squash/fault_returns
vcd add /tb_cpu_squash/fault_returns
log /tb_cpu_squash/normal_stores
vcd add /tb_cpu_squash/normal_stores
log /tb_cpu_squash/mmio_writes
vcd add /tb_cpu_squash/mmio_writes
log /tb_cpu_squash/csr_writes
vcd add /tb_cpu_squash/csr_writes
run -all
quit -f -code 0
