"""Verify the six frozen squash runs and package their original evidence."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
from PIL import Image

MAIN = Path(r'D:\FPGA\TriHaRiscv-main')
CPU = Path(r'D:\FPGA\TriHaRiscv-cpu-windows')
REPORT = Path(__file__).resolve().parent
SUPPORT = MAIN/'docs/verification/cpu/system_support'
RUNS = [
    ('delay32', 'squash-20261029T153735115500Z', 'none'),
    ('delay64', 'squash-20261029T153737907785Z', 'none'),
    ('negative_store', 'squash-20261029T153740371503Z', 'store'),
    ('negative_mmio', 'squash-20261029T153742773491Z', 'mmio'),
    ('negative_csr', 'squash-20261029T153745195864Z', 'csr'),
    ('negative_load', 'squash-20261029T153747599114Z', 'load'),
]

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(p, value):
    Path(p).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def vcd_snapshots(p):
    selected = set('clk rst_n d_rd d_wr d_accept d_pending d_ack d_error d_data saved_addr mscratch mepc mcause mtval wrong_fetched wrong_decoded recovered traps returns fault_returns normal_stores mmio_writes csr_writes'.split())
    ids, widths, parts, state, snapshots, scope = {}, {}, {}, {}, [], []
    header, time = True, 0
    for line in p.read_text().splitlines():
        words = line.split()
        if header:
            if line.startswith('$scope'): scope.append(words[2])
            elif line.startswith('$upscope'): scope.pop()
            elif line.startswith('$var') and scope == ['tb_cpu_squash'] and words[4] in selected:
                bit = re.fullmatch(r'\[(\d+)\]', words[5]) if len(words)>6 else None
                idx = int(bit[1]) if bit else None
                ids[words[3]] = words[4], idx
                widths[words[4]] = max(widths.get(words[4], 0), idx+1 if bit else int(words[2]))
            elif line.startswith('$enddefinitions'): header = False
            continue
        if line.startswith('#'):
            snapshots.append((time, dict(state)))
            time = int(line[1:])
        elif words:
            if line[0] in 'bB': bits, ident = words[0][1:], words[1]
            elif line[0] in '01xzXZ': bits, ident = line[0], line[1:].strip()
            else: continue
            if ident not in ids: continue
            name, idx = ids[ident]
            val = None if set(bits.lower()) & {'x','z'} else int(bits, 2)
            if idx is None: state[name] = val
            else:
                b = parts.setdefault(name, {})
                b[idx] = val
                state[name] = sum(v<<i for i,v in b.items()) if len(b)==widths[name] and all(v is not None for v in b.values()) else None
    snapshots.append((time, dict(state)))
    assert {n for n,i in ids.values()} == selected
    return snapshots

def retirement(p):
    rows = [[int(x,16) for x in s.split()] for s in p.read_text().splitlines()]
    for r in rows:
        if r[2] == 0: r[3] = 0
    return rows

files, records, checks, sequences = {}, [], {}, []
for label, name, negative in RUNS:
    directory = CPU/'build/cpu'/name
    result = json.loads((directory/'result.json').read_text())
    is_negative = negative != 'none'
    assert result['status'] == ('FAIL' if is_negative else 'PASS')
    assert result['negative'] == negative and result['runner_return_code'] == int(is_negative)
    assert all(result[k] for k in ('source_unchanged','external_unchanged','generated_unchanged'))
    assert all(c['return_code']==0 and not c['timed_out'] for c in result['commands'])
    for rel, digest in result['input_hashes'].items():
        assert sha(directory/'src'/rel) == sha(CPU/rel) == digest, rel
        files[f'inputs/{label}/{rel}'] = directory/'src'/rel
    for rel, digest in result['generated_input_hashes'].items():
        assert sha(directory/rel) == digest
    for path, digest in result['external_hashes'].items():
        assert sha(path) == digest, path
    for rel, digest in result['output_hashes'].items():
        assert sha(directory/rel) == digest, directory/rel
    for p in directory.iterdir():
        if p.is_file() and p.name != 'modelsim.ini': files[f'runs/{label}/{p.name}'] = p
    log = (directory/'simulation.log').read_text(errors='replace')
    if is_negative:
        reason = {'store':'wrong-path SRAM store','mmio':'wrong-path MMIO write','csr':'wrong-path CSR write','load':'wrong-path SRAM store'}[negative]
        assert result['negative_rejected'] and 'CPU_SQUASH_FAIL '+reason in log and '** Fatal:' in log
        checks[label+'_rejected'] = True
    else:
        assert not re.search(r'CPU_SQUASH_FAIL|\*\* (Error|Fatal)', log)
        line = next(s for s in log.splitlines() if 'CPU_SQUASH_PASS' in s)
        statistics = {k:int(v,16 if k in ('fetched','decoded','recoveries') else 10) for k,v in re.findall(r'(\w+)=([0-9a-f]+)(?:\s|$)', line)}
        assert statistics['fetched']==0x7f and statistics['decoded']==0x78 and statistics['recoveries']==0xf
        assert statistics['cycles']==(750 if label=='delay32' else 1102)
        assert statistics['checks']==(2199 if label=='delay32' else 3031)
        rows = retirement(directory/'squash.wb.log')
        assert len(rows)==162
        symbols = result['symbols']
        forbidden = {symbols[f'bad_b_{i}'] for i in range(1,4)} | {symbols[f'bad_f_{i}'] for i in range(1,5)}
        faults = [symbols[f'fault_{i}'] for i in range(1,5)]
        assert all(r[0] not in forbidden|set(faults) for r in rows)
        mrets = [i for i,r in enumerate(rows) if r[1]==0x30200073]
        assert len(mrets)==4
        for i, index in enumerate(mrets,1):
            assert rows[index+1][0]==symbols[f'resume_f_{i}']
            hits = [r for r in rows if r[0]==symbols[f'resume_f_{i}']]
            assert len(hits)==1 and hits[0][2:4]==[20,0x11223344]
        snapshots = vcd_snapshots(directory/'squash.vcd')
        final = snapshots[-1][1]
        assert final['wrong_fetched']==0x7f and final['wrong_decoded']==0x78 and final['recovered']==0xf
        assert all(final[k]==4 for k in ('traps','returns','fault_returns'))
        assert all(final[k]==1 for k in ('normal_stores','mmio_writes','csr_writes'))
        assert final['mscratch']==0x12345678
        events = (directory/'squash.events.log').read_text()
        for i,(t,epc,tval) in enumerate(re.findall(r'TRAP time=(\d+) count=\d+ mepc=([0-9a-f]+) mtval=([0-9a-f]+)', events),1):
            s = next(s for ts,s in reversed(snapshots) if ts<=int(t))
            assert int(epc,16)==faults[i-1] and int(tval,16)==0x8001f080
            assert s['mcause']==5 and s['mtval']==0x8001f080 and s['mepc']==faults[i-1]
        response_rows = re.findall(r'FAULT_RESPONSE time=(\d+) error=(\d+) data=([0-9a-f]+)',events)
        assert len(response_rows)==4
        for t,error,data in response_rows:
            s = next(s for ts,s in reversed(snapshots) if ts<=int(t))
            assert error=='1' and int(data,16)==0xdeafbeef
            assert s['d_ack']==1 and s['d_error']==1 and s['d_data']==0xdeafbeef and s['saved_addr']==0x8001f080
        accepted_young = [ts for ts,s in snapshots if s.get('clk')==1 and s.get('rst_n')==1 and s.get('d_rd')==1 and s.get('d_accept')==1 and s.get('d_pending')==1]
        # The TB checks accepted requests at each active edge; no duplicate/unrequested response is injected.
        checks.update({label+'_retirement_and_recovery':True,label+'_vcd_fault_csrs':True,label+'_vcd_error_data':True,label+'_coverage_masks':True})
        sequences.append(rows)
        result['raw_pass_statistics_reparsed'] = statistics
    records.append(dict(label=label, directory=str(directory), result_sha256=sha(directory/'result.json'), result=result))

assert sequences[0] == sequences[1]
checks['complete_retirement_sequences_equal_with_x0_data_normalized'] = True
image = MAIN/'docs/technical-report/figure/cpu-system-squash-modelsim-original.jpg'
assert sha(image) == sha(REPORT/'final-wave.jpg')
dimensions = Image.open(image).size
assert dimensions == (3060,1920)
files['figures/'+image.name] = image
files['view/squash-view.do'] = REPORT/'squash-view.do'
files['README.md'] = SUPPORT/'SQUASH_README.md'
files['validation/package.py'] = Path(__file__)
latex = MAIN/'docs/technical-report/latex'
log = (latex/'技术文档.log').read_text(encoding='utf-8',errors='replace')
assert not re.search(r'Overfull|undefined references|multiply defined|^!|LaTeX Warning|Package .+ Warning',log,re.M)
pages = int(re.search(r'Output written on .+?\((\d+) pages',log)[1])
document = dict(appendix=str(latex/'chapters/06-appendix.tex'),appendix_sha256=sha(latex/'chapters/06-appendix.tex'),
                pdf=str(latex/'技术文档.pdf'),pdf_sha256=sha(latex/'技术文档.pdf'),
                compile_log=str(latex/'技术文档.log'),compile_log_sha256=sha(latex/'技术文档.log'),
                compile_return_code=0,pages=pages,pdf_rendered_or_previewed=False)
index = dict(status='PASS',records=records,independent_checks=checks,document=document,
             scope='CPU B.4 pipeline redirect/exception side-effect isolation, public port RTL simulation',
             lsu_boundary='Blocking LSU: younger request is prevented before acceptance, not an accepted old load returning across redirect',
             screenshot=dict(file=str(image),sha256=sha(image),dimensions=list(dimensions),mouse_pointer_visible=False,cropped=False,redrawn=False,
                             source='Original @oai/sky ModelSim Wave window screenshot bytes',window_ns=[1900,3300],
                             wlf=str(CPU/'build/cpu'/RUNS[0][1]/'squash.wlf'),wlf_sha256=sha(CPU/'build/cpu'/RUNS[0][1]/'squash.wlf'),viewer_closed=True),
             packaged_file_hashes={name:sha(p) for name,p in sorted(files.items())})
index_path = SUPPORT/'squash_run_2026-10-30.json'
save(index_path,index)
files['squash_run_2026-10-30.json'] = index_path
archive = SUPPORT/'cpu-squash-support-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()): z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files) and z.testzip() is None
    for name,p in files.items(): assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
summary = dict(status='PASS',positive_runs=2,negative_runs_rejected=4,retirement_sequences_equal=True,
               retirement_rows_each=162,scenarios=7,independent_checks=len(checks),
               index=str(index_path),index_sha256=sha(index_path),archive=str(archive),archive_sha256=sha(archive),
               archive_entries_verified=len(files),archive_bytes=archive.stat().st_size,document=document,
               screenshot_sha256=sha(image),production_rtl_modified=False,physical_implementation_run=False,board_programmed=False,
               desktop_recovery='Prior kernel-assets initialization failed with os error 3; fresh runtime enumerated windows and saved original screenshot. Prior missing path remains unknown.')
save(MAIN/'docs/verification/cpu/system_squash_side_effects_2026-10-30.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
