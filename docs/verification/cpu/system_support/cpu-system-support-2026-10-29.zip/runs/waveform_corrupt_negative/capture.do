onerror {quit -f -code 2}
onbreak {quit -f -code 3}
vcd file {runtime.vcd}
log /tb_cpu_cache_soc/clk
vcd add /tb_cpu_cache_soc/clk
log /tb_cpu_cache_soc/rst_n
vcd add /tb_cpu_cache_soc/rst_n
log /tb_cpu_cache_soc/ddr_ready
vcd add /tb_cpu_cache_soc/ddr_ready
log /tb_cpu_cache_soc/ddr_fault
vcd add /tb_cpu_cache_soc/ddr_fault
log /tb_cpu_cache_soc/fault
vcd add /tb_cpu_cache_soc/fault
log /tb_cpu_cache_soc/protocol_fault
vcd add /tb_cpu_cache_soc/protocol_fault
log /tb_cpu_cache_soc/done
vcd add /tb_cpu_cache_soc/done
log /tb_cpu_cache_soc/exit_code
vcd add /tb_cpu_cache_soc/exit_code
log /tb_cpu_cache_soc/status_polls
vcd add /tb_cpu_cache_soc/status_polls
log /tb_cpu_cache_soc/local_writes
vcd add /tb_cpu_cache_soc/local_writes
log /tb_cpu_cache_soc/trap_count
vcd add /tb_cpu_cache_soc/trap_count
log /tb_cpu_cache_soc/private_exec
vcd add /tb_cpu_cache_soc/private_exec
log /tb_cpu_cache_soc/shared_exec
vcd add /tb_cpu_cache_soc/shared_exec
log /tb_cpu_cache_soc/arvalid
vcd add /tb_cpu_cache_soc/arvalid
log /tb_cpu_cache_soc/arready
vcd add /tb_cpu_cache_soc/arready
log /tb_cpu_cache_soc/araddr
vcd add /tb_cpu_cache_soc/araddr
log /tb_cpu_cache_soc/rvalid
vcd add /tb_cpu_cache_soc/rvalid
log /tb_cpu_cache_soc/rready
vcd add /tb_cpu_cache_soc/rready
log /tb_cpu_cache_soc/rresp
vcd add /tb_cpu_cache_soc/rresp
log /tb_cpu_cache_soc/awvalid
vcd add /tb_cpu_cache_soc/awvalid
log /tb_cpu_cache_soc/awready
vcd add /tb_cpu_cache_soc/awready
log /tb_cpu_cache_soc/awaddr
vcd add /tb_cpu_cache_soc/awaddr
log /tb_cpu_cache_soc/bvalid
vcd add /tb_cpu_cache_soc/bvalid
log /tb_cpu_cache_soc/bready
vcd add /tb_cpu_cache_soc/bready
log /tb_cpu_cache_soc/bresp
vcd add /tb_cpu_cache_soc/bresp
log /tb_cpu_cache_soc/uart_tx
vcd add /tb_cpu_cache_soc/uart_tx
log /tb_cpu_cache_soc/u_dut/inst_addr
vcd add /tb_cpu_cache_soc/u_dut/inst_addr
log /tb_cpu_cache_soc/u_dut/inst_req
vcd add /tb_cpu_cache_soc/u_dut/inst_req
log /tb_cpu_cache_soc/u_dut/inst_accept
vcd add /tb_cpu_cache_soc/u_dut/inst_accept
log /tb_cpu_cache_soc/u_dut/inst_valid
vcd add /tb_cpu_cache_soc/u_dut/inst_valid
log /tb_cpu_cache_soc/u_dut/data_addr
vcd add /tb_cpu_cache_soc/u_dut/data_addr
log /tb_cpu_cache_soc/u_dut/data_re
vcd add /tb_cpu_cache_soc/u_dut/data_re
log /tb_cpu_cache_soc/u_dut/data_wstrb
vcd add /tb_cpu_cache_soc/u_dut/data_wstrb
log /tb_cpu_cache_soc/u_dut/data_accept
vcd add /tb_cpu_cache_soc/u_dut/data_accept
log /tb_cpu_cache_soc/u_dut/data_ack
vcd add /tb_cpu_cache_soc/u_dut/data_ack
log /tb_cpu_cache_soc/u_dut/data_error
vcd add /tb_cpu_cache_soc/u_dut/data_error
log /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_request_o
vcd add /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_request_o
log /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_pc_o
vcd add /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_pc_o
log /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/exception_i
vcd add /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/exception_i
log /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mepc_q
vcd add /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mepc_q
log /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mcause_q
vcd add /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mcause_q
log /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mtval_q
vcd add /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mtval_q
run -all
quit -f -code 0
