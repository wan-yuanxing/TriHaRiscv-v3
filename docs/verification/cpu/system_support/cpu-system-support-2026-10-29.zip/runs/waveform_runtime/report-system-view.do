view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix unsigned /tb_cpu_cache_soc/clk
add wave -noupdate -label rst_n -radix unsigned /tb_cpu_cache_soc/rst_n
add wave -noupdate -label ddr_ready -radix unsigned /tb_cpu_cache_soc/ddr_ready
add wave -noupdate -label ddr_fault -radix unsigned /tb_cpu_cache_soc/ddr_fault
add wave -noupdate -label fault -radix unsigned /tb_cpu_cache_soc/fault
add wave -noupdate -label protocol_fault -radix unsigned /tb_cpu_cache_soc/protocol_fault
add wave -noupdate -label done -radix unsigned /tb_cpu_cache_soc/done
add wave -noupdate -label exit_code -radix hexadecimal /tb_cpu_cache_soc/exit_code
add wave -noupdate -label status_polls -radix unsigned /tb_cpu_cache_soc/status_polls
add wave -noupdate -label local_writes -radix unsigned /tb_cpu_cache_soc/local_writes
add wave -noupdate -label trap_count -radix unsigned /tb_cpu_cache_soc/trap_count
add wave -noupdate -label private_exec -radix unsigned /tb_cpu_cache_soc/private_exec
add wave -noupdate -label shared_exec -radix unsigned /tb_cpu_cache_soc/shared_exec
add wave -noupdate -label arvalid -radix unsigned /tb_cpu_cache_soc/arvalid
add wave -noupdate -label arready -radix unsigned /tb_cpu_cache_soc/arready
add wave -noupdate -label araddr -radix hexadecimal /tb_cpu_cache_soc/araddr
add wave -noupdate -label rvalid -radix unsigned /tb_cpu_cache_soc/rvalid
add wave -noupdate -label rready -radix unsigned /tb_cpu_cache_soc/rready
add wave -noupdate -label rresp -radix unsigned /tb_cpu_cache_soc/rresp
add wave -noupdate -label awvalid -radix unsigned /tb_cpu_cache_soc/awvalid
add wave -noupdate -label awready -radix unsigned /tb_cpu_cache_soc/awready
add wave -noupdate -label awaddr -radix hexadecimal /tb_cpu_cache_soc/awaddr
add wave -noupdate -label bvalid -radix unsigned /tb_cpu_cache_soc/bvalid
add wave -noupdate -label bready -radix unsigned /tb_cpu_cache_soc/bready
add wave -noupdate -label bresp -radix unsigned /tb_cpu_cache_soc/bresp
add wave -noupdate -label uart_tx -radix unsigned /tb_cpu_cache_soc/uart_tx
add wave -noupdate -label inst_addr -radix hexadecimal /tb_cpu_cache_soc/u_dut/inst_addr
add wave -noupdate -label inst_req -radix unsigned /tb_cpu_cache_soc/u_dut/inst_req
add wave -noupdate -label inst_accept -radix unsigned /tb_cpu_cache_soc/u_dut/inst_accept
add wave -noupdate -label inst_valid -radix unsigned /tb_cpu_cache_soc/u_dut/inst_valid
add wave -noupdate -label data_addr -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_addr
add wave -noupdate -label data_re -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_re
add wave -noupdate -label data_wstrb -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_wstrb
add wave -noupdate -label data_accept -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_accept
add wave -noupdate -label data_ack -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_ack
add wave -noupdate -label data_error -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_error
add wave -noupdate -label branch_csr_request_o -radix unsigned /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_request_o
add wave -noupdate -label branch_csr_pc_o -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_pc_o
add wave -noupdate -label exception_i -radix unsigned /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/exception_i
add wave -noupdate -label csr_mepc_q -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mepc_q
add wave -noupdate -label csr_mcause_q -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mcause_q
add wave -noupdate -label csr_mtval_q -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mtval_q
configure wave -namecolwidth 320
configure wave -valuecolwidth 330
configure wave -rowmargin 35
configure wave -timelineunits ns
update
after 2000 {wave zoom range 20000ns 28000ns}
