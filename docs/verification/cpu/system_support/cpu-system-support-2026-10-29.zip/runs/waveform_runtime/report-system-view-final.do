view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_cache_soc/clk
add wave -noupdate -label ddr_ready -radix hexadecimal /tb_cpu_cache_soc/ddr_ready
add wave -noupdate -label ddr_fault -radix hexadecimal /tb_cpu_cache_soc/ddr_fault
add wave -noupdate -label fault -radix hexadecimal /tb_cpu_cache_soc/fault
add wave -noupdate -label data_addr -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_addr
add wave -noupdate -label data_re -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_re
add wave -noupdate -label data_ack -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_ack
add wave -noupdate -label data_error -radix hexadecimal /tb_cpu_cache_soc/u_dut/data_error
add wave -noupdate -label trap_count -radix hexadecimal /tb_cpu_cache_soc/trap_count
add wave -noupdate -label mcause -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mcause_q
add wave -noupdate -label mtval -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mtval_q
add wave -noupdate -label mepc -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/u_csrfile/csr_mepc_q
add wave -noupdate -label redirect -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_request_o
add wave -noupdate -label target_pc -radix hexadecimal /tb_cpu_cache_soc/u_dut/u_core/u_cpu/u_csr/branch_csr_pc_o
add wave -noupdate -label done -radix hexadecimal /tb_cpu_cache_soc/done
add wave -noupdate -label exit_code -radix hexadecimal /tb_cpu_cache_soc/exit_code
configure wave -namecolwidth 320
configure wave -valuecolwidth 330
configure wave -rowmargin 30
configure wave -timelineunits ns
update
after 2000 {wave zoom range 172700ns 173650ns}
