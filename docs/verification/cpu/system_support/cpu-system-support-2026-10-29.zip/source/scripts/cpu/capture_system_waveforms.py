"""Capture the existing local-system runtime self-check from frozen inputs."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True, type=Path)
    parser.add_argument('--broken', action='store_true')
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    if baseline.is_dir():
        baseline = baseline / 'result.json'
    parent = json.loads(baseline.read_text(encoding='utf-8'))
    if parent['status'] != 'PASS' or parent['test'] != 'runtime':
        raise ValueError('A passing runtime baseline is required')
    work = ROOT / 'build/cpu' / ('wave-system-runtime-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    work.mkdir(parents=True)
    result = dict(status='RUNNING', directory=str(work), baseline=str(baseline),
                  baseline_sha256=sha(baseline), cache_enable=parent['cache_enable'],
                  broken=args.broken, input_hashes={}, external_hashes=parent['external_hashes'],
                  commands=[], output_hashes={}, source_unchanged=False,
                  scope='CPU local ROM/SRAM/MMIO, paired caches and modeled AXI128 memory; RTL simulation')
    paths = {}
    result_path = work / 'result.json'
    def save():
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    def native(command, label):
        record = dict(command=[str(c) for c in command], return_code=None, timed_out=False)
        result['commands'].append(record)
        proc = subprocess.Popen(record['command'], cwd=work, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        try:
            data, _ = proc.communicate(timeout=120)
        except subprocess.TimeoutExpired:
            record['timed_out'] = True
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            data, _ = proc.communicate()
        record['return_code'] = proc.returncode
        (work / (label+'.log')).write_bytes(data)
        if record['timed_out'] or proc.returncode:
            raise RuntimeError(f'{label}: return={proc.returncode}, timeout={record["timed_out"]}')
        return data.decode('utf-8', errors='replace')
    save()
    try:
        for key, digest in parent['input_hashes'].items():
            source = baseline.parent / 'src' / key
            assert sha(source) == digest, source
            paths[str(source)] = digest
        for key, digest in parent['external_hashes'].items():
            assert sha(key) == digest, key
        for name in ('rom.hex', 'sram.hex', 'firmware.elf', 'firmware.map'):
            source = baseline.parent / name
            assert sha(source) == parent['output_hashes'][name], source
            shutil.copyfile(source, work / name)
            paths[str(source)] = sha(source)
        paths[str(baseline)] = sha(baseline)
        paths[str(Path(__file__).resolve())] = sha(__file__)
        top = '/tb_cpu_cache_soc'
        public = 'clk rst_n ddr_ready ddr_fault fault protocol_fault done exit_code status_polls local_writes trap_count private_exec shared_exec arvalid arready araddr rvalid rready rresp awvalid awready awaddr bvalid bready bresp uart_tx'.split()
        scope = [top+'/'+name for name in public]
        scope += [top+'/u_dut/'+name for name in 'inst_addr inst_req inst_accept inst_valid data_addr data_re data_wstrb data_accept data_ack data_error'.split()]
        csr = top+'/u_dut/u_core/u_cpu/u_csr'
        scope += [csr+'/'+name for name in ('branch_csr_request_o', 'branch_csr_pc_o')]
        scope += [csr+'/u_csrfile/'+name for name in ('exception_i', 'csr_mepc_q', 'csr_mcause_q', 'csr_mtval_q')]
        do_file = work / 'capture.do'
        do_lines = ['onerror {quit -f -code 2}', 'onbreak {quit -f -code 3}',
                    'vcd file {runtime.vcd}']
        for signal in scope:
            do_lines += [f'log {signal}', f'vcd add {signal}']
        do_lines += ['run -all', 'quit -f -code 0']
        do_file.write_text('\n'.join(do_lines)+'\n', encoding='utf-8')
        paths[str(do_file)] = sha(do_file)
        result['waveform_scope'] = scope
        result['input_hashes'] = paths
        for tool in ('vmap.exe', 'vlib.exe', 'vlog.exe'):
            commands = [c['command'] for c in parent['commands'] if Path(c['command'][0]).name.lower() == tool]
            assert len(commands) == 1
            native(commands[0], tool[:-4])
        sim = next(c['command'][0] for c in parent['commands'] if Path(c['command'][0]).name.lower() == 'vsim.exe')
        output = native([sim, '-c', '-l', 'batch-transcript.log', '-wlf', 'runtime.wlf',
                         '-onfinish', 'exit', '-voptargs=+acc',
                         '-gCACHE_ENABLE='+str(int(parent['cache_enable'])),
                         '-gCORRUPT_DATA='+str(int(args.broken)), '-gMAX_CYCLES=200000',
                         'work.tb_cpu_cache_soc', '-do', str(do_file)], 'simulation')
        if 'CPU_CACHE_SOC_PASS' not in output or any(s in output for s in ('CPU_CACHE_FAIL', '** Error', '** Fatal')):
            raise RuntimeError('Actual system self-check did not pass')
        assert (work/'runtime.wlf').stat().st_size > 0
        result.update(status='PASS', pass_line=next(s for s in output.splitlines() if 'CPU_CACHE_SOC_PASS' in s))
    except Exception as error:
        result.update(status='FAIL', error=str(error))
    finally:
        result['source_unchanged'] = all(Path(p).is_file() and sha(p) == h for p, h in paths.items())
        result['external_unchanged'] = all(sha(p) == h for p,h in result['external_hashes'].items())
        if not result['source_unchanged'] or not result['external_unchanged']:
            result.update(status='FAIL', error='Frozen input changed')
        result['output_hashes'] = {p.name:sha(p) for p in work.iterdir() if p.is_file() and p != result_path}
        result['runner_return_code'] = 0 if result['status'] == 'PASS' else 1
        save()
    print('CPU_SYSTEM_WAVEFORM', result['status'], result_path, result.get('error', ''))
    return result['runner_return_code']

if __name__ == '__main__':
    sys.exit(main())
