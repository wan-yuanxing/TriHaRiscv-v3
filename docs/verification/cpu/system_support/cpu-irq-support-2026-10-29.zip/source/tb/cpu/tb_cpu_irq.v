/* Reuse the control firmware bench with the deployed single-issue predictor. */
`timescale 1ns / 1ps
module tb_cpu_irq #(parameter integer BROKEN = 0);
    tb_cpu_ordered #(.DUAL_ISSUE(0), .IRQ_TEST(1), .BROKEN(BROKEN)) u_system ();
    defparam u_system.u_dut.NUM_BTB_ENTRIES = 512;
    defparam u_system.u_dut.NUM_BTB_ENTRIES_W = 9;
    defparam u_system.u_dut.BTB_DIRECT_MAPPED = 1;
    defparam u_system.u_dut.NUM_BHT_ENTRIES = 512;
    defparam u_system.u_dut.NUM_BHT_ENTRIES_W = 9;
    defparam u_system.u_dut.NUM_RAS_ENTRIES = 4;
    defparam u_system.u_dut.NUM_RAS_ENTRIES_W = 2;
    initial begin
        #1;
        if (u_system.u_dut.SUPPORT_DUAL_ISSUE != 0 ||
            u_system.u_dut.NUM_BTB_ENTRIES != 512 ||
            u_system.u_dut.BTB_DIRECT_MAPPED != 1 ||
            u_system.u_dut.NUM_BHT_ENTRIES != 512 ||
            u_system.u_dut.NUM_RAS_ENTRIES != 4 ||
            u_system.u_dut.GSHARE_ENABLE != 0)
            $fatal(1, "CPU_IRQ_FAIL elaborated configuration");
        $display("CPU_IRQ_CONFIG single=1 btb=512 direct=1 bht=512 ras=4 gshare=0");
    end
endmodule
