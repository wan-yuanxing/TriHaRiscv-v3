"""Run the existing IRQ firmware on the deployed single-issue core configuration."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
SIM = Path(r'D:\modeltech64_2020.4\win64')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True, type=Path)
    parser.add_argument('--broken', action='store_true')
    args = parser.parse_args()
    baseline = args.baseline.resolve()
    parent = json.loads(baseline.read_text(encoding='utf-8-sig'))
    if parent['status'] != 'PASS' or not parent['interrupt']:
        raise ValueError('A passing interrupt firmware baseline is required')
    work = ROOT / 'build/cpu' / ('wave-system-irq-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    work.mkdir(parents=True)
    result = dict(status='RUNNING', directory=str(work), baseline=str(baseline),
                  baseline_sha256=sha(baseline), broken=args.broken,
                  input_hashes={}, external_hashes=dict(parent['external_input_hashes']),
                  commands=[], source_unchanged=False, output_hashes={})
    result_path = work / 'result.json'
    def save():
        result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    def native(exe, arguments, label):
        command = [str(exe), *map(str, arguments)]
        result['external_hashes'][str(exe)] = sha(exe)
        row = dict(command=command, return_code=None, timed_out=False)
        result['commands'].append(row)
        proc = subprocess.Popen(command, cwd=work, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        try:
            output, _ = proc.communicate(timeout=90)
        except subprocess.TimeoutExpired:
            row['timed_out'] = True
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            output, _ = proc.communicate()
        row['return_code'] = proc.returncode
        (work/(label+'.log')).write_bytes(output)
        if proc.returncode or row['timed_out']:
            raise RuntimeError(f'{label}: return {proc.returncode}, timeout {row["timed_out"]}')
        return output.decode('utf-8', errors='replace')
    save()
    try:
        for name, digest in parent['input_hashes'].items():
            source = ROOT / name
            if sha(source) != digest:
                raise ValueError('Baseline source changed: '+name)
            dest = work/'src'/name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, dest)
            result['input_hashes'][name] = digest
        for name in ('tb/cpu/tb_cpu_irq.v', 'scripts/cpu/capture_irq_waveforms.py'):
            source = ROOT/name
            dest = work/'src'/name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, dest)
            result['input_hashes'][name] = sha(source)
        for path, digest in result['external_hashes'].items():
            if sha(path) != digest:
                raise ValueError('Primitive model changed: '+path)
        for name in ('control.elf', 'tcm.bin', 'symbols.stdout.log'):
            source = baseline.parent/name
            if sha(source) != parent['output_hashes'][name]:
                raise ValueError('Firmware changed: '+name)
            shutil.copyfile(source, work/name)
        result['firmware_sha256'] = sha(work/'control.elf')
        result['image_sha256'] = sha(work/'tcm.bin')
        source_command = next(c for c in parent['native_commands']
                              if Path(c['tool']).name == 'vlog.exe' and c['arguments'][:2] == ['-work', 'candidate'])
        compile_args = []
        for arg in source_command['arguments']:
            compile_args.append(arg.replace(str(ROOT), str(work/'src')).replace(ROOT.as_posix(), (work/'src').as_posix()))
        compile_args.append(str(work/'src/tb/cpu/tb_cpu_irq.v'))
        native(SIM/'vmap.exe', ['-c'], 'vmap')
        native(SIM/'vlib.exe', ['candidate'], 'vlib')
        native(SIM/'vlog.exe', compile_args, 'compile')
        fault_pc = re.search(r'(?m)^([0-9a-f]+)\s+\w\s+fetch_fault_target\s*$', (work/'symbols.stdout.log').read_text()).group(1)
        top = '/tb_cpu_irq/u_system'
        signals = [top+'/'+s for s in 'clk irq d_addr d_wr d_ack d_pending i_pc i_rd i_accept cycles retired stores trap_mask'.split()]
        csr = top+'/u_dut/u_csr'
        signals += [csr+'/'+s for s in ('branch_csr_request_o', 'branch_csr_pc_o')]
        signals += [csr+'/u_csrfile/'+s for s in ('csr_mcause_q','csr_mepc_q','csr_mtval_q','csr_sr_q','csr_mie_q','csr_mtvec_q')]
        lines = ['onerror {quit -f -code 2}', 'onbreak {quit -f -code 3}', 'vcd file {irq.vcd}']
        for signal in signals:
            lines += [f'log {signal}', f'vcd add {signal}']
        lines += ['run -all', 'quit -f -code 0']
        (work/'capture.do').write_text('\n'.join(lines)+'\n', encoding='utf-8')
        output = native(SIM/'vsim.exe', ['-c', '-l', 'batch-transcript.log', '-wlf', 'irq.wlf', '-onfinish', 'exit',
                         '-voptargs=+acc', '-gBROKEN='+str(int(args.broken)), 'candidate.tb_cpu_irq',
                         '+MEM_IMAGE='+str(work/'tcm.bin'), '+FETCH_FAULT_PC='+fault_pc, '+SEED=37',
                         '+TRACE_PREFIX=cpu-irq', '-do', str(work/'capture.do')], 'simulation')
        if 'CPU_IRQ_CONFIG single=1 btb=512 direct=1 bht=512 ras=4 gshare=0' not in output:
            raise RuntimeError('Configuration was not verified')
        if 'CPU_ORDER_PASS dual=0' not in output or re.search(r'CPU_(ORDER|IRQ)_FAIL|\*\* (Error|Fatal)', output):
            raise RuntimeError('IRQ firmware self-check failed')
        result.update(status='PASS', pass_line=next(s for s in output.splitlines() if 'CPU_ORDER_PASS' in s), waveform_scope=signals,
                      configuration=dict(single_issue=True, btb=512, bht=512, ras=4, gshare=False))
    except Exception as error:
        result.update(status='FAIL', error=str(error))
    finally:
        result['source_unchanged'] = all(sha(ROOT/p) == h and sha(work/'src'/p) == h for p,h in result['input_hashes'].items())
        result['external_unchanged'] = all(sha(p) == h for p,h in result['external_hashes'].items())
        if not result['source_unchanged'] or not result['external_unchanged']:
            result.update(status='FAIL', error='Input hash mismatch')
        result['runner_return_code'] = 0 if result['status'] == 'PASS' else 1
        result['output_hashes'] = {p.name:sha(p) for p in work.iterdir() if p.is_file() and p != result_path}
        save()
    print('CPU_IRQ_WAVEFORM', result['status'], result_path, result.get('error',''))
    return result['runner_return_code']

if __name__ == '__main__':
    sys.exit(main())
