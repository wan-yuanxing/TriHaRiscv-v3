onerror {quit -f -code 2}
onbreak {quit -f -code 3}
vcd file {irq.vcd}
log /tb_cpu_irq/u_system/clk
vcd add /tb_cpu_irq/u_system/clk
log /tb_cpu_irq/u_system/irq
vcd add /tb_cpu_irq/u_system/irq
log /tb_cpu_irq/u_system/d_addr
vcd add /tb_cpu_irq/u_system/d_addr
log /tb_cpu_irq/u_system/d_wr
vcd add /tb_cpu_irq/u_system/d_wr
log /tb_cpu_irq/u_system/d_ack
vcd add /tb_cpu_irq/u_system/d_ack
log /tb_cpu_irq/u_system/d_pending
vcd add /tb_cpu_irq/u_system/d_pending
log /tb_cpu_irq/u_system/i_pc
vcd add /tb_cpu_irq/u_system/i_pc
log /tb_cpu_irq/u_system/i_rd
vcd add /tb_cpu_irq/u_system/i_rd
log /tb_cpu_irq/u_system/i_accept
vcd add /tb_cpu_irq/u_system/i_accept
log /tb_cpu_irq/u_system/cycles
vcd add /tb_cpu_irq/u_system/cycles
log /tb_cpu_irq/u_system/retired
vcd add /tb_cpu_irq/u_system/retired
log /tb_cpu_irq/u_system/stores
vcd add /tb_cpu_irq/u_system/stores
log /tb_cpu_irq/u_system/trap_mask
vcd add /tb_cpu_irq/u_system/trap_mask
log /tb_cpu_irq/u_system/u_dut/u_csr/branch_csr_request_o
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/branch_csr_request_o
log /tb_cpu_irq/u_system/u_dut/u_csr/branch_csr_pc_o
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/branch_csr_pc_o
log /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mcause_q
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mcause_q
log /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mepc_q
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mepc_q
log /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mtval_q
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mtval_q
log /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_sr_q
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_sr_q
log /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mie_q
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mie_q
log /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mtvec_q
vcd add /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mtvec_q
run -all
quit -f -code 0
