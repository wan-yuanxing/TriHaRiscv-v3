view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_irq/u_system/clk
add wave -noupdate -label irq -radix hexadecimal /tb_cpu_irq/u_system/irq
add wave -noupdate -label d_addr -radix hexadecimal /tb_cpu_irq/u_system/d_addr
add wave -noupdate -label d_wr -radix hexadecimal /tb_cpu_irq/u_system/d_wr
add wave -noupdate -label d_ack -radix hexadecimal /tb_cpu_irq/u_system/d_ack
add wave -noupdate -label mcause -radix hexadecimal /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mcause_q
add wave -noupdate -label mepc -radix hexadecimal /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mepc_q
add wave -noupdate -label mtval -radix hexadecimal /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mtval_q
add wave -noupdate -label mstatus -radix hexadecimal /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_sr_q
add wave -noupdate -label mie -radix hexadecimal /tb_cpu_irq/u_system/u_dut/u_csr/u_csrfile/csr_mie_q
configure wave -namecolwidth 300
configure wave -valuecolwidth 340
configure wave -rowmargin 28
configure wave -timelineunits ns
update
after 2000 {wave zoom range 34000ns 35600ns}
