from pathlib import Path
import hashlib
import json
import re
import zipfile
from PIL import Image

CPU = Path(r'D:\FPGA\TriHaRiscv-cpu-windows')
MAIN = Path(r'D:\FPGA\TriHaRiscv-main')
VERIFY = MAIN / 'docs/verification/cpu'
SUPPORT = VERIFY / 'system_support'
POS = CPU / 'build/cpu/wave-system-irq-20261029T114008329257Z'
NEG = CPU / 'build/cpu/wave-system-irq-20261029T113924175961Z'

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read_json(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def save(p, data):
    Path(p).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

entries = {}
records = []
for name, directory, negative in [('positive', POS, False), ('negative', NEG, True)]:
    r = read_json(directory/'result.json')
    assert r['source_unchanged'] and r['external_unchanged']
    assert r['status'] == ('FAIL' if negative else 'PASS')
    assert r['runner_return_code'] == (1 if negative else 0)
    for key, digest in r['input_hashes'].items():
        assert sha(directory/'src'/key) == digest
        assert sha(CPU/key) == digest
        entries['source/'+key] = directory/'src'/key
    for key, digest in r['external_hashes'].items():
        assert sha(key) == digest
    for key, digest in r['output_hashes'].items():
        assert sha(directory/key) == digest, directory/key
        entries[f'runs/{name}/{key}'] = directory/key
    log = (directory/'simulation.log').read_text(errors='replace')
    assert 'CPU_IRQ_CONFIG single=1 btb=512 direct=1 bht=512 ras=4 gshare=0' in log
    if negative:
        assert 'CPU_ORDER_FAIL program_exit' in log and '** Fatal:' in log
    else:
        assert 'CPU_ORDER_PASS dual=0 cycles=3582 traps=511 retired=864 stores=92 delayed=1124' in log
        assert not re.search(r'\*\* (Error|Fatal)', log)
    assert all(c['return_code'] == 0 and not c['timed_out'] for c in r['commands'])
    entries[f'runs/{name}/result.json'] = directory/'result.json'
    records.append(dict(name=name, result=str(directory/'result.json'), result_sha256=sha(directory/'result.json'),
                        expected_outcome='REJECTED' if negative else 'PASS', **r))

# Read only the selected scalar and register signals after all changes at each
# timestamp, so simultaneous CSR updates are checked as one sampled state.
selected = {'irq','csr_mcause_q','csr_mepc_q','csr_sr_q','csr_mie_q','csr_mtval_q'}
ids = {}
header = True
time_ps = 0
state = {}
snapshots = []
dirty = False
for line in (POS/'irq.vcd').open():
    a = line.split()
    if header:
        if line.startswith('$var') and a[4] in selected and (int(a[2]) > 1 or len(a) == 6):
            ids[a[3]] = a[4]
        elif line.startswith('$enddefinitions'):
            header = False
        continue
    if line.startswith('#'):
        if dirty:
            snapshots.append(dict(time_ns=time_ps/1000, **state))
        dirty = False
        time_ps = int(line[1:])
    elif a:
        if line[0] in 'bB':
            bits, ident = a[0][1:], a[1]
        elif line[0] in '01xzXZ':
            bits, ident = line[0], line[1:].strip()
        else:
            continue
        if ident in ids:
            try:
                state[ids[ident]] = int(bits, 2)
            except ValueError:
                state[ids[ident]] = None
            dirty = True
if dirty:
    snapshots.append(dict(time_ns=time_ps/1000, **state))

symbols = {name:int(value,16) for value, name in re.findall(r'(?m)^([0-9a-f]+)\s+\w\s+(\w+)\s*$', (POS/'symbols.stdout.log').read_text())}
request = next(s for s in snapshots if s.get('irq') == 1)
entry = next(s for s in snapshots if s.get('csr_mcause_q') == 0x8000000b)
returned = next(s for s in snapshots if s['time_ns'] > entry['time_ns'] and s.get('csr_sr_q',0) & 8)
checks = {}
def check(name, good):
    checks[name] = bool(good)
    assert good, name

check('irq_before_entry', request['time_ns'] < entry['time_ns'])
check('external_irq_cause', entry['csr_mcause_q'] == 0x8000000b)
check('mepc_is_firmware_wait_label', entry['csr_mepc_q'] == symbols['wait_irq'])
check('interrupt_mtval_zero', entry['csr_mtval_q'] == 0)
check('entry_mie_clear', entry['csr_sr_q'] & 8 == 0)
check('entry_mpie_set', entry['csr_sr_q'] & 0x80 != 0)
check('entry_mpp_machine', entry['csr_sr_q'] & 0x1800 == 0x1800)
check('mie_before_irq', request['csr_mie_q'] == 0x800)
check('handler_disables_mie', returned['csr_mie_q'] == 0)
check('mret_restores_mie', returned['csr_sr_q'] & 8 != 0)
check('mret_preserves_mepc', returned['csr_mepc_q'] == entry['csr_mepc_q'])
check('irq_deasserted_before_return', returned['irq'] == 0)
wb = [[int(x,16) for x in line.split()] for line in (POS/'cpu-irq.wb.log').read_text().splitlines()]
irq_read = next(i for i,row in enumerate(wb) if row[0] == symbols['trap_handler'] and row[3] == 0x8000000b)
mret_index = next(i for i in range(irq_read, len(wb)) if wb[i][1] == 0x30200073)
check('retirement_resumes_at_mepc', wb[mret_index+1][0] == symbols['wait_irq'])
check('handler_count_exactly_one', any(row[2] == 9 and row[3] == 1 for row in wb[irq_read:mret_index]))
exceptions = [[int(x,16) for x in line.split()] for line in (POS/'cpu-irq.exception.log').read_text().splitlines()]
check('one_external_irq_event', sum(row[0] == 0x20 for row in exceptions) == 1)
check('nine_mret_events', sum(row[0] == 0x33 for row in exceptions) == 9)
check('retired_count', len(wb) == 864)
check('store_count', len((POS/'cpu-irq.store.log').read_text().splitlines()) == 92)

image = MAIN/'docs/technical-report/figure/cpu-system-external-irq-modelsim-original.jpg'
with Image.open(image) as im:
    assert im.format == 'JPEG' and im.size == (2553,1440)
view = POS/'irq-view-corrected.do'
entries['figures/'+image.name] = image
entries['runs/positive/'+view.name] = view
for license_path in ('rtl/cpu/vendor/LICENSE', 'rtl/cpu/vendor/UPSTREAM.json'):
    entries['source/'+license_path] = CPU/license_path
entries['IRQ_README.md'] = SUPPORT/'IRQ_README.md'
index = dict(status='PASS', section='B.4', scope='Single-issue full-core external interrupt and return',
             configuration=dict(btb=512, direct_mapped=True, bht=512, ras=4, gshare=False),
             cycles=3582, retired=864, stores=92, synchronous_exception_classes=8, external_interrupts=1,
             trap_mask='0x1FF', positive_tests_pass=1, negative_tests_rejected=1,
             checks=checks, checks_passed=len(checks),
             events=dict(request=request, entry=entry, returned=returned), runs=records,
             screenshot=dict(file=str(image),sha256=sha(image),width=2553,height=1440,window_ns=[34000,35600],
                             view_do=str(view),view_sha256=sha(view),mouse_pointer_visible=False,
                             source='Native ModelSim WLF window through @oai/sky; no crop or pixel changes'),
             notes=['No I/D cache or DDR is instantiated; 128 KiB behavior RAM serves the CPU ports.',
                    'The negative flips returned load data and fails the startup program check before IRQ; it does not establish an IRQ-specific fault injection.',
                    'The earlier default-predictor baseline supplies the same firmware image only; its cycle counts are not used for this result.'],
             production_rtl_modified=False,physical_timing_revalidated=False,board_programmed=False)
index['packaged_file_hashes'] = {k:sha(v) for k,v in sorted(entries.items())}
index_path = SUPPORT/'irq-run-index.json'
save(index_path,index)
entries['irq-run-index.json'] = index_path
entries['provenance/package.py'] = Path(__file__)
archive = SUPPORT/'cpu-irq-support-2026-10-29.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,path in sorted(entries.items()):
        z.write(path,key)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries)
    for key,path in entries.items():
        assert hashlib.sha256(z.read(key)).hexdigest() == sha(path)
docdir = MAIN/'docs/technical-report/latex'
log = docdir/'技术文档.log'
log_text = log.read_text(encoding='utf-8',errors='replace')
assert not re.search(r'Overfull|undefined references|multiply defined|^!|LaTeX Warning|Package .+ Warning',log_text,re.M)
pages = int(re.search(r'Output written on .+?\((\d+) pages',log_text).group(1))
doc = {key:str(path) for key,path in dict(appendix=docdir/'chapters/06-appendix.tex',pdf=docdir/'技术文档.pdf',compile_log=log).items()}
doc.update({key+'_sha256':sha(path) for key,path in list(doc.items())})
doc.update(pages=pages,compile_return_code=0,pdf_rendered_or_previewed=False,unresolved_references=False,overfull_boxes=False)
evidence = dict(status='PASS',scope=index['scope'],positive_tests_pass=1,negative_tests_rejected=1,
                checks_passed=len(checks),cycles=3582,retired=864,stores=92,
                run_index=str(index_path),run_index_sha256=sha(index_path),archive=str(archive),archive_sha256=sha(archive),
                archive_entries_verified=len(entries),archive_bytes=archive.stat().st_size,document=doc,
                production_rtl_modified=False,physical_timing_revalidated=False,board_programmed=False)
save(VERIFY/'system_irq_waveforms_2026-10-29.json', evidence)
print(json.dumps(dict(status='PASS',checks_passed=len(checks),pages=pages,archive_entries=len(entries),archive_bytes=archive.stat().st_size),indent=2))
