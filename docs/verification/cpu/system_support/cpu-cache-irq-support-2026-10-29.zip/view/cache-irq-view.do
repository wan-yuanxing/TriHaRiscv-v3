view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 18
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_cache_irq/clk
add wave -noupdate -label phase -radix hexadecimal /tb_cpu_cache_irq/phase
add wave -noupdate -label irq -radix hexadecimal /tb_cpu_cache_irq/irq
add wave -noupdate -label read_pending -radix hexadecimal /tb_cpu_cache_irq/read_pending
add wave -noupdate -label read_wait -radix hexadecimal /tb_cpu_cache_irq/read_wait
add wave -noupdate -label araddr -radix hexadecimal /tb_cpu_cache_irq/araddr
add wave -noupdate -label rvalid -radix hexadecimal /tb_cpu_cache_irq/rvalid
add wave -noupdate -label rready -radix hexadecimal /tb_cpu_cache_irq/rready
add wave -noupdate -label D_ack -radix hexadecimal /tb_cpu_cache_irq/u_dut/data_ack
add wave -noupdate -label D_rdata -radix hexadecimal /tb_cpu_cache_irq/u_dut/data_rdata
add wave -noupdate -label mcause -radix hexadecimal /tb_cpu_cache_irq/mcause
add wave -noupdate -label mepc -radix hexadecimal /tb_cpu_cache_irq/mepc
add wave -noupdate -label mstatus -radix hexadecimal /tb_cpu_cache_irq/mstatus
add wave -noupdate -label mie -radix hexadecimal /tb_cpu_cache_irq/mie
add wave -noupdate -label entries -radix hexadecimal /tb_cpu_cache_irq/entries
add wave -noupdate -label returns -radix hexadecimal /tb_cpu_cache_irq/returns
add wave -noupdate -label resumes -radix hexadecimal /tb_cpu_cache_irq/resumes
configure wave -namecolwidth 300
configure wave -valuecolwidth 290
configure wave -rowmargin 16
configure wave -timelineunits ns
update
after 1000 {wave zoom range 114450ns 116050ns}
