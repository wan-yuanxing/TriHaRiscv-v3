"""Reject incomplete/reordered results rather than accepting a lone PASS word."""
import pytest
from run_cache_soc import validate_irq_result

OUTPUT = 'CPU_CACHE_IRQ_PASS cycles=100 checks=20 entries=3 returns=3 resumes=3 wait_irq_cycles=60'
EVENTS = '\n'.join(f'{event} phase={phase}' for phase in range(1, 4) for event in ('ASSERT','ENTRY','RETURN'))


def test_complete_result():
    assert validate_irq_result(OUTPUT, EVENTS)['entries'] == 3


@pytest.mark.parametrize('output,events', [
    ('PASS', EVENTS),
    (OUTPUT.replace('returns=3', 'returns=2'), EVENTS),
    (OUTPUT.replace('wait_irq_cycles=60', 'wait_irq_cycles=0'), EVENTS),
    (OUTPUT, EVENTS.replace('ENTRY phase=2', 'ENTRY phase=1')),
    (OUTPUT, EVENTS + '\nENTRY phase=3'),
])
def test_reject_incomplete_result(output, events):
    with pytest.raises(ValueError):
        validate_irq_result(output, events)
