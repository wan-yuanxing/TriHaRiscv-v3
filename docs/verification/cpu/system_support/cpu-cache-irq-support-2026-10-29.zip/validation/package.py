"""Verify raw cache/IRQ evidence and freeze the incremental submission pack."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
from PIL import Image

MAIN = Path(r'D:\FPGA\TriHaRiscv-main')
CPU = Path(r'D:\FPGA\TriHaRiscv-cpu-windows')
POS = CPU/'build/cpu/cache-soc-irq-20261029T121332762068Z'
NEG = CPU/'build/cpu/cache-soc-irq-20261029T121308537521Z'
REG = CPU/'build/cpu/cache-soc-runtime-20261029T121336225017Z'
SUPPORT = MAIN/'docs/verification/cpu/system_support'
REPORT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))


def save(p, data):
    Path(p).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


files = {}
records = []
for name, directory, negative in [('positive',POS,False),('negative',NEG,True),('runtime_regression',REG,False)]:
    result = load(directory/'result.json')
    assert result['status'] == ('FAIL' if negative else 'PASS')
    assert result['runner_return_code'] == int(negative)
    assert result['source_unchanged'] and result['external_unchanged'] and result['generated_unchanged']
    for p, digest in result['input_hashes'].items():
        assert sha(directory/'src'/p) == digest, p
        assert sha(CPU/p) == digest, p
        files[f'inputs/{name}/{p}'] = directory/'src'/p
    for p, digest in result['generated_input_hashes'].items() if 'generated_input_hashes' in result else []:
        assert sha(directory/p) == digest
    for p, digest in result['external_hashes'].items():
        assert sha(p) == digest
    for p, digest in result['output_hashes'].items():
        assert sha(directory/p) == digest, directory/p
        if not p.startswith('src/') and p != 'modelsim.ini':
            files[f'runs/{name}/{p}'] = directory/p
    files[f'runs/{name}/result.json'] = directory/'result.json'
    text = (directory/'simulation.log').read_text(errors='replace')
    if negative:
        assert result['expected_negative']
        assert 'CPU_CACHE_FAIL MRET must not skip original interrupted PC' in text and '** Fatal' in text
    else:
        assert not re.search(r'\*\* (Error|Fatal)|CPU_CACHE_FAIL', text)
    if name == 'runtime_regression':
        assert 'cycles=26356 checks=1277 reads=14 writes=35 traps=3 cache=1' in text
    assert all(c['return_code'] == 0 and not c['timed_out'] for c in result['commands'])
    records.append(dict(name=name, result=str(directory/'result.json'), result_sha256=sha(directory/'result.json'),
                        expected='REJECTED' if negative else 'PASS', **result))

# Recheck actual raw VCD snapshots, independently of the TB PASS word.
selected = set('phase irq read_pending read_wait rvalid mepc mcause mstatus mie entries returns resumes saved_araddr'.split())
ids = {}
bit_parts = {}
widths = {}
scopes = []
snapshots = []
state = {}
time_ps = 0
header = True
with (POS/'cache-irq.vcd').open() as stream:
    for line in stream:
        words = line.split()
        if header:
            if line.startswith('$scope'):
                scopes.append(words[2])
            elif line.startswith('$upscope'):
                scopes.pop()
            elif line.startswith('$var') and scopes == ['tb_cpu_cache_irq'] and words[4] in selected:
                bit = re.fullmatch(r'\[(\d+)\]', words[5]) if len(words) > 6 else None
                index = int(bit[1]) if bit else None
                ids[words[3]] = (words[4],index)
                widths[words[4]] = max(widths.get(words[4],0),index+1 if bit else int(words[2]))
            elif line.startswith('$enddefinitions'):
                header = False
            continue
        if line.startswith('#'):
            snapshots.append((time_ps, dict(state)))
            time_ps = int(line[1:])
        elif words:
            if line[0] in 'bB':
                bits, ident = words[0][1:], words[1]
            elif line[0] in '01xzXZ':
                bits, ident = line[0], line[1:].strip()
            else:
                continue
            if ident in ids:
                name,index = ids[ident]
                value = int(bits,2) if not set(bits.lower()) & {'x','z'} else None
                if index is None:
                    state[name] = value
                else:
                    parts = bit_parts.setdefault(name,{})
                    parts[index] = value
                    state[name] = sum(v<<i for i,v in parts.items()) if len(parts) == widths[name] and all(v is not None for v in parts.values()) else None
snapshots.append((time_ps, dict(state)))
assert {name for name,index in ids.values()} == selected


def sample(time_ps):
    return next(s for t,s in reversed(snapshots) if t <= time_ps)


events = []
for line in (POS/'cache-irq.events.log').read_text().splitlines():
    m = re.match(r'(ASSERT|ENTRY|RETURN) phase=(\d+) time=(\d+)',line)
    assert m, line
    events.append((m[1],int(m[2]),int(m[3])))
assert [(kind,phase) for kind,phase,t in events] == [(k,p) for p in range(1,4) for k in ('ASSERT','ENTRY','RETURN')]
checks = {}
expected_epc = [0x80004060,0x80004094,0x800040c8]
for kind,phase,t in events:
    s = sample(t)
    if kind == 'ENTRY':
        good = s['mcause'] == 0x8000000b and s['mepc'] == expected_epc[phase-1] and s['mstatus'] == 0x1880 and s['mie'] == 0x800
    elif kind == 'RETURN':
        good = s['mepc'] == expected_epc[phase-1] and s['mstatus'] == 0x88 and s['mie'] == 0 and s['returns'] == phase
    elif phase == 2:
        good = s['irq'] == 1 and s['read_pending'] == 1 and s['rvalid'] == 0 and s['read_wait'] == 64 and s['saved_araddr'] == 0x80002400
    else:
        good = s['irq'] == 1 and s['phase'] == phase
    checks[f'{kind.lower()}_phase_{phase}'] = bool(good)
    assert good, (kind,phase,t,s)
wb = [[int(v,16) for v in line.split()] for line in (POS/'cache-irq.wb.log').read_text().splitlines()]
assert len(wb) == records[0]['statistics']['retired'] == 1110
for phase,pc,value in [(1,0x8000405c,0x13579bdf),(2,0x80004090,0x2468ace0),(3,0x800040c4,0x31415926)]:
    rows = [r for r in wb if r[0] == pc]
    assert len(rows) == 1 and rows[0][2] == 20 and rows[0][3] == value
    after = [r for r in wb if r[0] == pc+4]
    assert len(after) == 1 and after[0][2] == 22 and after[0][3] == phase
    checks[f'load_and_next_retire_once_phase_{phase}'] = True
    checks[f'load_value_phase_{phase}'] = True
returns = [i for i,r in enumerate(wb) if r[1] == 0x30200073]
assert len(returns) == 3
for phase,i in enumerate(returns,1):
    assert wb[i+1][0] == expected_epc[phase-1]
    checks[f'resumes_at_saved_mepc_phase_{phase}'] = True

image = MAIN/'docs/technical-report/figure/cpu-system-cache-irq-modelsim-original.jpg'
assert Image.open(image).size == (2553,1440)
view = REPORT/'cache-irq-view.do'
files['figures/'+image.name] = image
files['view/'+view.name] = view
files['README.md'] = SUPPORT/'CACHE_IRQ_README.md'
files['validation/test_cache_irq.py'] = CPU/'scripts/cpu/test_cache_irq.py'
files['validation/package.py'] = Path(__file__)
latex = MAIN/'docs/technical-report/latex'
log = (latex/'技术文档.log').read_text(encoding='utf-8',errors='replace')
assert not re.search(r'Overfull|undefined references|multiply defined|^!|LaTeX Warning|Package .+ Warning',log,re.M)
pages = int(re.search(r'Output written on .+?\((\d+) pages',log).group(1))
document = dict(appendix=str(latex/'chapters/06-appendix.tex'), appendix_sha256=sha(latex/'chapters/06-appendix.tex'),
                pdf=str(latex/'技术文档.pdf'),pdf_sha256=sha(latex/'技术文档.pdf'),
                compile_log=str(latex/'技术文档.log'),compile_log_sha256=sha(latex/'技术文档.log'),
                pages=pages,compile_return_code=0,pdf_rendered_or_previewed=False)
index = load(SUPPORT/'cache_irq_run_2026-10-29.json')
index.update(records=records,raw_vcd_and_retirement_checks=checks,document=document,
             screenshot=dict(file=str(image),sha256=sha(image),width=2553,height=1440,
                             wlf=str(POS/'cache-irq.wlf'),wlf_sha256=sha(POS/'cache-irq.wlf'),
                             view_do=str(view),view_do_sha256=sha(view),window_ns=[114450,116050],
                             mouse_pointer_visible=False,cropped=False,redrawn=False,
                             source='Original ModelSim Wave window screenshot bytes from @oai/sky',viewer_closed=True),
             packaged_file_hashes={name:sha(p) for name,p in sorted(files.items())})
index_path = SUPPORT/'cache_irq_run_2026-10-29.json'
save(index_path,index)
files['cache_irq_run_2026-10-29.json'] = index_path
archive = SUPPORT/'cpu-cache-irq-support-2026-10-29.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()):
        z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(files) and z.testzip() is None
    for name,p in files.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == sha(p),name
summary = dict(status='PASS',scope='B.4 cache-enabled IRQ interaction',
               positive_runs=1,negative_runs_rejected=1,unchanged_runtime_regression=True,
               statistics=records[0]['statistics'],raw_evidence_checks=len(checks),
               index=str(index_path),index_sha256=sha(index_path),
               archive=str(archive),archive_sha256=sha(archive),archive_entries_verified=len(files),
               archive_bytes=archive.stat().st_size,document=document,
               production_rtl_modified=False,physical_timing_revalidated=False,board_programmed=False)
save(MAIN/'docs/verification/cpu/system_cache_irq_waveforms_2026-10-29.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
