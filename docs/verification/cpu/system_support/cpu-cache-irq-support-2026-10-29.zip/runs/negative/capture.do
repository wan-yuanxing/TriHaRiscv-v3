onerror {quit -f -code 2}
onbreak {quit -f -code 3}
vcd file {cache-irq.vcd}
log /tb_cpu_cache_irq/clk
vcd add /tb_cpu_cache_irq/clk
log /tb_cpu_cache_irq/rst_n
vcd add /tb_cpu_cache_irq/rst_n
log /tb_cpu_cache_irq/phase
vcd add /tb_cpu_cache_irq/phase
log /tb_cpu_cache_irq/irq
vcd add /tb_cpu_cache_irq/irq
log /tb_cpu_cache_irq/fired
vcd add /tb_cpu_cache_irq/fired
log /tb_cpu_cache_irq/entries
vcd add /tb_cpu_cache_irq/entries
log /tb_cpu_cache_irq/returns
vcd add /tb_cpu_cache_irq/returns
log /tb_cpu_cache_irq/resumes
vcd add /tb_cpu_cache_irq/resumes
log /tb_cpu_cache_irq/target_pending
vcd add /tb_cpu_cache_irq/target_pending
log /tb_cpu_cache_irq/target_addr
vcd add /tb_cpu_cache_irq/target_addr
log /tb_cpu_cache_irq/target_tag
vcd add /tb_cpu_cache_irq/target_tag
log /tb_cpu_cache_irq/ddr_ready
vcd add /tb_cpu_cache_irq/ddr_ready
log /tb_cpu_cache_irq/fault
vcd add /tb_cpu_cache_irq/fault
log /tb_cpu_cache_irq/protocol_fault
vcd add /tb_cpu_cache_irq/protocol_fault
log /tb_cpu_cache_irq/done
vcd add /tb_cpu_cache_irq/done
log /tb_cpu_cache_irq/exit_code
vcd add /tb_cpu_cache_irq/exit_code
log /tb_cpu_cache_irq/read_pending
vcd add /tb_cpu_cache_irq/read_pending
log /tb_cpu_cache_irq/saved_araddr
vcd add /tb_cpu_cache_irq/saved_araddr
log /tb_cpu_cache_irq/read_wait
vcd add /tb_cpu_cache_irq/read_wait
log /tb_cpu_cache_irq/arvalid
vcd add /tb_cpu_cache_irq/arvalid
log /tb_cpu_cache_irq/arready
vcd add /tb_cpu_cache_irq/arready
log /tb_cpu_cache_irq/araddr
vcd add /tb_cpu_cache_irq/araddr
log /tb_cpu_cache_irq/arid
vcd add /tb_cpu_cache_irq/arid
log /tb_cpu_cache_irq/rvalid
vcd add /tb_cpu_cache_irq/rvalid
log /tb_cpu_cache_irq/rready
vcd add /tb_cpu_cache_irq/rready
log /tb_cpu_cache_irq/rlast
vcd add /tb_cpu_cache_irq/rlast
log /tb_cpu_cache_irq/rdata
vcd add /tb_cpu_cache_irq/rdata
log /tb_cpu_cache_irq/read_beat
vcd add /tb_cpu_cache_irq/read_beat
log /tb_cpu_cache_irq/delayed_irq_cycles
vcd add /tb_cpu_cache_irq/delayed_irq_cycles
log /tb_cpu_cache_irq/mepc
vcd add /tb_cpu_cache_irq/mepc
log /tb_cpu_cache_irq/mcause
vcd add /tb_cpu_cache_irq/mcause
log /tb_cpu_cache_irq/mstatus
vcd add /tb_cpu_cache_irq/mstatus
log /tb_cpu_cache_irq/mie
vcd add /tb_cpu_cache_irq/mie
log /tb_cpu_cache_irq/exception
vcd add /tb_cpu_cache_irq/exception
log /tb_cpu_cache_irq/wb_pc
vcd add /tb_cpu_cache_irq/wb_pc
log /tb_cpu_cache_irq/wb_valid
vcd add /tb_cpu_cache_irq/wb_valid
log /tb_cpu_cache_irq/saved_epc
vcd add /tb_cpu_cache_irq/saved_epc
log /tb_cpu_cache_irq/u_dut/inst_addr
vcd add /tb_cpu_cache_irq/u_dut/inst_addr
log /tb_cpu_cache_irq/u_dut/inst_req
vcd add /tb_cpu_cache_irq/u_dut/inst_req
log /tb_cpu_cache_irq/u_dut/inst_valid
vcd add /tb_cpu_cache_irq/u_dut/inst_valid
log /tb_cpu_cache_irq/u_dut/inst_accept
vcd add /tb_cpu_cache_irq/u_dut/inst_accept
log /tb_cpu_cache_irq/u_dut/data_addr
vcd add /tb_cpu_cache_irq/u_dut/data_addr
log /tb_cpu_cache_irq/u_dut/data_re
vcd add /tb_cpu_cache_irq/u_dut/data_re
log /tb_cpu_cache_irq/u_dut/data_accept
vcd add /tb_cpu_cache_irq/u_dut/data_accept
log /tb_cpu_cache_irq/u_dut/data_ack
vcd add /tb_cpu_cache_irq/u_dut/data_ack
log /tb_cpu_cache_irq/u_dut/data_rdata
vcd add /tb_cpu_cache_irq/u_dut/data_rdata
log /tb_cpu_cache_irq/u_dut/data_resp_tag
vcd add /tb_cpu_cache_irq/u_dut/data_resp_tag
run -all
quit -f -code 0
