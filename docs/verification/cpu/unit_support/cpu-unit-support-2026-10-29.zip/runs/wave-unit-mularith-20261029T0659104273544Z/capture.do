onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-unit-mularith-20261029T0659104273544Z/mularith.vcd}
vcd add -r /*
run -all
quit -f -code 0
