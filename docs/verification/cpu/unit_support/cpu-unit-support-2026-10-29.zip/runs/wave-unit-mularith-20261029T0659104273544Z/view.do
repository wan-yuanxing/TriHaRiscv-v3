view wave
quietly WaveActivateNextPane {}
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/clk
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/rst
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/valid
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/hold
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/opcode
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/operand_a
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/operand_b
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/early_low
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/early_valid
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/result
add wave -noupdate -radix hexadecimal /tb_multiplier_payload/valid_out
configure wave -namecolwidth 245
configure wave -valuecolwidth 100
configure wave -timelineunits ns
update
wave zoom range 0ns 400ns
