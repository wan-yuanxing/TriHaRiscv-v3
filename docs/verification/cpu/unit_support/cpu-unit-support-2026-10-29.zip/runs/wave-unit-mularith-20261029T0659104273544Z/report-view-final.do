view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
font configure waveFontBold -family {Courier New} -size 20 -weight bold
add wave -noupdate -label clk -radix hexadecimal /tb_multiplier_payload/clk
add wave -noupdate -label rst -radix hexadecimal /tb_multiplier_payload/rst
add wave -noupdate -label valid -radix hexadecimal /tb_multiplier_payload/valid
add wave -noupdate -label hold -radix hexadecimal /tb_multiplier_payload/hold
add wave -noupdate -label opcode -radix hexadecimal /tb_multiplier_payload/opcode
add wave -noupdate -label operand_a -radix hexadecimal /tb_multiplier_payload/operand_a
add wave -noupdate -label operand_b -radix hexadecimal /tb_multiplier_payload/operand_b
add wave -noupdate -label early_low -radix hexadecimal /tb_multiplier_payload/early_low
add wave -noupdate -label early_valid -radix hexadecimal /tb_multiplier_payload/early_valid
add wave -noupdate -label result -radix hexadecimal /tb_multiplier_payload/result
add wave -noupdate -label valid_out -radix hexadecimal /tb_multiplier_payload/valid_out
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -timelineunits ns
configure wave -signalnamewidth 1
configure wave -rowmargin 35
update
after 2000 {wave zoom range 50ns 140ns}
