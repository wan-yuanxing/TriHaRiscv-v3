view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
font configure waveFontBold -family {Courier New} -size 20 -weight bold
add wave -noupdate -label clk -radix hexadecimal /tb_csr_functional/clk
add wave -noupdate -label valid -radix hexadecimal /tb_csr_functional/valid
add wave -noupdate -label opcode -radix hexadecimal /tb_csr_functional/opcode
add wave -noupdate -label operand -radix hexadecimal /tb_csr_functional/operand
add wave -noupdate -label read_valid -radix hexadecimal /tb_csr_functional/read_valid
add wave -noupdate -label read_value -radix hexadecimal /tb_csr_functional/read_value
add wave -noupdate -label wb_write -radix hexadecimal /tb_csr_functional/wb_write
add wave -noupdate -label wb_addr -radix hexadecimal /tb_csr_functional/wb_addr
add wave -noupdate -label wb_data -radix hexadecimal /tb_csr_functional/wb_data
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -timelineunits ns
configure wave -signalnamewidth 1
configure wave -rowmargin 35
update
after 2000 {wave zoom range 80ns 360ns}
