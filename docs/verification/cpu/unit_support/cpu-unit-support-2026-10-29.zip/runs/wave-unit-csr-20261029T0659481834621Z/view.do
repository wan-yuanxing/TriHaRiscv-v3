view wave
quietly WaveActivateNextPane {}
add wave -noupdate -radix hexadecimal /tb_csr_functional/clk
add wave -noupdate -radix hexadecimal /tb_csr_functional/rst
add wave -noupdate -radix hexadecimal /tb_csr_functional/valid
add wave -noupdate -radix hexadecimal /tb_csr_functional/opcode
add wave -noupdate -radix hexadecimal /tb_csr_functional/operand
add wave -noupdate -radix hexadecimal /tb_csr_functional/read_valid
add wave -noupdate -radix hexadecimal /tb_csr_functional/read_value
add wave -noupdate -radix hexadecimal /tb_csr_functional/wb_write
add wave -noupdate -radix hexadecimal /tb_csr_functional/wb_addr
add wave -noupdate -radix hexadecimal /tb_csr_functional/wb_data
add wave -noupdate -radix hexadecimal /tb_csr_functional/trap
add wave -noupdate -radix hexadecimal /tb_csr_functional/trap_pc
add wave -noupdate -radix hexadecimal /tb_csr_functional/branch_valid
add wave -noupdate -radix hexadecimal /tb_csr_functional/branch_pc
configure wave -namecolwidth 245
configure wave -valuecolwidth 100
configure wave -timelineunits ns
update
wave zoom range 0ns 400ns
