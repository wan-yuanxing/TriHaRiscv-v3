view wave
quietly WaveActivateNextPane {}
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/clk
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/rst
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/valid
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/opcode
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/a
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/b
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/golden_valid
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/candidate_valid
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/golden_value
add wave -noupdate -radix hexadecimal /tb_divider_arithmetic/candidate_value
configure wave -namecolwidth 245
configure wave -valuecolwidth 100
configure wave -timelineunits ns
update
wave zoom range 0ns 400ns
