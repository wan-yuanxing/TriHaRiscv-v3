view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
font configure waveFontBold -family {Courier New} -size 20 -weight bold
add wave -noupdate -label clk -radix hexadecimal /tb_divider_arithmetic/clk
add wave -noupdate -label valid -radix hexadecimal /tb_divider_arithmetic/valid
add wave -noupdate -label opcode -radix hexadecimal /tb_divider_arithmetic/opcode
add wave -noupdate -label a -radix hexadecimal /tb_divider_arithmetic/a
add wave -noupdate -label b -radix hexadecimal /tb_divider_arithmetic/b
add wave -noupdate -label expected -radix hexadecimal /tb_divider_arithmetic/expected
add wave -noupdate -label golden_valid -radix hexadecimal /tb_divider_arithmetic/golden_valid
add wave -noupdate -label candidate_valid -radix hexadecimal /tb_divider_arithmetic/candidate_valid
add wave -noupdate -label golden_value -radix hexadecimal /tb_divider_arithmetic/golden_value
add wave -noupdate -label candidate_value -radix hexadecimal /tb_divider_arithmetic/candidate_value
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -timelineunits ns
configure wave -signalnamewidth 1
configure wave -rowmargin 35
update
after 2000 {wave zoom range 2480ns 3020ns}
