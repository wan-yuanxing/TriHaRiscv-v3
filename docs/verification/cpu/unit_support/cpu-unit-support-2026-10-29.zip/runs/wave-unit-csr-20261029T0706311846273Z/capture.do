onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-unit-csr-20261029T0706311846273Z/csr.vcd}
vcd add -r /*
run -all
quit -f -code 0
