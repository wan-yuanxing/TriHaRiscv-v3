# CPU 单元级仿真支撑材料

本包对应技术文档 B.2 的乘法器、除法器和 CSR 验证。

| 单元 | 正例结果 | 负例结果 |
|---|---|---|
| 乘法器 | 2730 次有效结果检查，904 个 hold 周期 | 强制错误结果后触发 MUL_PAYLOAD_FAIL |
| 除法器 | 308 次算术操作，312 次完成检查，16 次快速完成 | 强制错误结果后触发 DIV_ARITH_FAIL |
| CSR | 21 次访问、91 项检查、六种指令形式、两次异常和一次返回 | 强制错误读值后触发 CSR_UNIT_FAIL |

`cpu-unit-support-2026-10-29.zip` 包含 `source/` 测试与依赖源码、`runs/` 六次运行的结果与日志、原始 WLF/VCD、显示脚本，以及 `figures/` 三张未重绘的 ModelSim 窗口原图。`run-index.json` 登记配置、命令、输入与输出 SHA-256、截图时间窗口和测试范围。

复跑入口（CPU 工程根目录，Windows PowerShell）：

```powershell
pwsh -NoProfile -File scripts/cpu/capture_unit_waveforms.ps1 -Test mularith
pwsh -NoProfile -File scripts/cpu/capture_unit_waveforms.ps1 -Test divarith
pwsh -NoProfile -File scripts/cpu/capture_unit_waveforms.ps1 -Test csr
```

对每项追加 `-Broken` 执行负例。正例脚本返回 0；负例脚本返回 1，实际数值错误见各次 `simulation.stdout.log`。原生 ModelSim 的 `$fatal` 可返回 0，因此判定同时检查失败文本与成功标志，不能只看仿真器退出码。

查看 WLF 时使用独立日志，例如 `vsim -l viewer.log -view mularith.wlf -do report-view-final.do`。三个正例目录的默认 `transcript` 已被 GUI 查看会话复用，未作为仿真证据打包；批处理 `simulation.stdout.log`、WLF/VCD、编译日志和输入哈希均与运行登记一致。

ALU、寄存器堆、模块级与系统级仿真由后续批次补齐。
