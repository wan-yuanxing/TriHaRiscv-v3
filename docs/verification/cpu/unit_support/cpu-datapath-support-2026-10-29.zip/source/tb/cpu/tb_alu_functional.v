/* Independent RV32 arithmetic, logic, comparison and shift oracle. */
`timescale 1ns / 1ps
`include "biriscv_defs.v"
module tb_alu_functional #(parameter integer CORRUPT_RESULT=0);
    reg [3:0] op=0;
    reg [31:0] a=0, b=0, expected=0;
    wire [31:0] result;
    reg [31:0] edges [0:7];
    reg [31:0] random_a=32'h7da15e37, random_b=32'h38e521b1;
    reg check_ok=0;
    integer checks=0, shifts=0, control, i, j, n, amount;
    biriscv_alu u_dut (.alu_op_i(op),.alu_a_i(a),.alu_b_i(b),.alu_p_o(result));
    initial if(CORRUPT_RESULT) force u_dut.alu_p_o=32'hc0ffee01;

    function [31:0] oracle;
        input [3:0] operation;
        input [31:0] x,y;
        reg signed [63:0] sx, sy, wide;
        begin
            sx={{32{x[31]}},x}; sy={{32{y[31]}},y}; wide=0;
            case(operation)
                `ALU_SHIFTL: oracle=x << y[4:0];
                `ALU_SHIFTR: oracle=x >> y[4:0];
                `ALU_SHIFTR_ARITH: begin wide=sx >>> y[4:0]; oracle=wide[31:0]; end
                `ALU_ADD: begin wide={32'b0,x}+{32'b0,y}; oracle=wide[31:0]; end
                `ALU_SUB: begin wide={32'b0,x}-{32'b0,y}; oracle=wide[31:0]; end
                `ALU_AND: oracle=x & y;
                `ALU_OR: oracle=x | y;
                `ALU_XOR: oracle=x ^ y;
                `ALU_LESS_THAN: oracle=x<y ? 1 : 0;
                `ALU_LESS_THAN_SIGNED: oracle=sx<sy ? 1 : 0;
                default: oracle=x;
            endcase
        end
    endfunction
    task test_value;
        input [3:0] operation;
        input [31:0] x,y;
        begin
            #1; check_ok=0; op=operation; a=x; b=y; expected=oracle(operation,x,y);
            #1;
            if(result!==expected)
                $fatal(1,"ALU_UNIT_FAIL op=%h a=%h b=%h expected=%h actual=%h",op,a,b,expected,result);
            checks=checks+1; check_ok=1;
            #8;
        end
    endtask
    initial begin
        edges[0]=0; edges[1]=1; edges[2]=32'hffffffff; edges[3]=32'h80000000;
        edges[4]=32'h7fffffff; edges[5]=32'haaaaaaaa; edges[6]=32'h55555555; edges[7]=32'h80000001;
        // Short readable sequence, then complete boundary and random sweeps.
        test_value(`ALU_ADD,32'hffffffff,1);
        test_value(`ALU_ADD,32'h7fffffff,1);
        test_value(`ALU_SUB,0,1);
        test_value(`ALU_SHIFTL,1,31);
        test_value(`ALU_SHIFTR,32'h80000000,4);
        test_value(`ALU_SHIFTR_ARITH,32'h80000000,4);
        test_value(`ALU_LESS_THAN,32'hffffffff,1);
        test_value(`ALU_LESS_THAN_SIGNED,32'hffffffff,1);
        test_value(`ALU_AND,32'haaaaaaaa,32'h55555555);
        test_value(`ALU_OR,32'haaaaaaaa,32'h55555555);
        test_value(`ALU_XOR,32'h12345678,32'hffffffff);
        test_value(`ALU_NONE,32'hcafef00d,32'h11223344);
        for(control=0;control<16;control=control+1)
            for(i=0;i<8;i=i+1)
                for(j=0;j<8;j=j+1) test_value(control,edges[i],edges[j]);
        for(control=1;control<=3;control=control+1)
            for(i=0;i<4;i=i+1)
                for(amount=0;amount<32;amount=amount+1) begin
                    test_value(control,edges[i+2],32'hdeadbe00|amount);
                    shifts=shifts+1;
                end
        for(n=0;n<1024;n=n+1) begin
            random_a={random_a[30:0],random_a[31]^random_a[21]^random_a[1]^random_a[0]};
            random_b={random_b[30:0],random_b[31]^random_b[21]^random_b[1]^random_b[0]};
            for(control=0;control<16;control=control+1) test_value(control,random_a,random_b);
        end
        if(checks!=17804 || shifts!=384) $fatal(1,"ALU_UNIT_FAIL coverage");
        $display("ALU_UNIT_PASS checks=%0d shift_sweep=%0d controls=16 boundary_pairs=64 random_pairs=1024",checks,shifts);
        $finish;
    end
endmodule
