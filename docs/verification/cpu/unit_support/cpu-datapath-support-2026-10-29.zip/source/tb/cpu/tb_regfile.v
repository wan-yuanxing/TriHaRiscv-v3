/* Independent synchronous-write/asynchronous-read register-file oracle. */
`timescale 1ns / 1ps
`ifndef RF_MODULE
`define RF_MODULE biriscv_regfile
`endif
module tb_regfile #(parameter BROKEN=0);
    reg clk=0, rst=0;
    reg [4:0] rd=0, ra=0, rb=0;
    reg [31:0] data=0;
    wire [31:0] value_a, value_b, unused_a, unused_b;
    reg [31:0] model [0:31];
    reg [31:0] random_q=32'h7da15e37;
    integer checks=0, writes=0, resets=0, scans=0, i, j;
    `RF_MODULE #(.SUPPORT_REGFILE_XILINX(0),.SUPPORT_DUAL_ISSUE(0)) u_dut (
        .clk_i(clk),.rst_i(rst),.rd0_i(rd),.rd1_i(5'b0),
        .rd0_value_i(data),.rd1_value_i(32'b0),
        .ra0_i(ra),.rb0_i(rb),.ra1_i(5'b0),.rb1_i(5'b0),
        .ra0_value_o(value_a),.rb0_value_o(value_b),.ra1_value_o(unused_a),.rb1_value_o(unused_b)
    );
    task check;
        begin
            if(value_a!==model[ra] || value_b!==model[rb])
                $fatal(1,"REGFILE_FAIL read ra=%d got=%h expected=%h rb=%d got=%h expected=%h",ra,value_a,model[ra],rb,value_b,model[rb]);
            if(unused_a!==0 || unused_b!==0) $fatal(1,"REGFILE_FAIL unused_single_issue_ports");
            checks=checks+2;
        end
    endtask
    task step;
        begin
            #5; clk=1;
            if(rst) begin
                for(j=0;j<32;j=j+1) model[j]=0;
                resets=resets+1;
            end
            else if(rd!=0) begin model[rd]=data; writes=writes+1; end
            #1; check;
            #4; clk=0;
        end
    endtask
    task scan;
        begin
            scans=scans+1;
            for(i=0;i<32;i=i+1) begin
                ra=i; rb=31-i;
                #1; check;
            end
        end
    endtask
    initial begin
        rst=1; step; rst=0;
        if(BROKEN) force u_dut.ra0_value_o=32'hc0ffee00;
        scan;
        // Inputs cannot update the word before WCLK; both ports follow
        // address changes without waiting for another clock edge.
        rd=5; data=32'h11223344; ra=5; rb=0; #2; check; step;
        data=32'h55667788; #2; check; step;
        rd=6; data=32'hcafef00d; ra=6; rb=5; #2; check; step;
        ra=5; rb=6; #2; check;
        rd=0; data=32'hffffffff; ra=0; rb=5; #2; check; step;
        for(i=0;i<32;i=i+1) begin
            rd=i; data=32'h13579bdf^(32'h01010101*i);
            ra=i; rb=i;
            step;
        end
        scan;
        repeat(1000) begin
            random_q={random_q[30:0],random_q[31]^random_q[21]^random_q[1]^random_q[0]};
            rd=random_q[4:0]; data=random_q^32'h98765432;
            ra=rd; rb=random_q[9:5];
            step;
        end
        scan;
        // A synchronous reset must not clear visible data before its edge.
        rst=1; #1; check;
        step; rst=0; scan;
        // Old RAM data must remain masked; rewriting one word reveals only it.
        rd=5'd17; data=32'hcafef00d; ra=17; rb=16; step;
        scan;
        rd=0; data=32'hffffffff; ra=0; rb=17; step;
        scan;
        $display("REGFILE_PASS checks=%0d writes=%0d resets=%0d async_scans=%0d zero_read_latency_writes_x0_sync_reset",checks,writes,resets,scans);
        $finish;
    end
endmodule
