view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label op -radix hexadecimal /tb_alu_functional/op
add wave -noupdate -label a -radix hexadecimal /tb_alu_functional/a
add wave -noupdate -label b -radix hexadecimal /tb_alu_functional/b
add wave -noupdate -label expected -radix hexadecimal /tb_alu_functional/expected
add wave -noupdate -label result -radix hexadecimal /tb_alu_functional/result
add wave -noupdate -label check_ok -radix hexadecimal /tb_alu_functional/check_ok
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 55
configure wave -timelineunits ns
update
after 2000 {wave zoom range 0ns 160ns}
