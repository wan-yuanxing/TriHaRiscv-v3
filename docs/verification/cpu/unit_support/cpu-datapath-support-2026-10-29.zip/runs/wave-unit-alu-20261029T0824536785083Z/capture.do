onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-unit-alu-20261029T0824536785083Z/alu.vcd}
vcd add -r /*
run -all
quit -f -code 0
