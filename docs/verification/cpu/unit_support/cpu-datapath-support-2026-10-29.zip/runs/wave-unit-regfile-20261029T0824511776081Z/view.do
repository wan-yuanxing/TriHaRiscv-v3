view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_regfile/clk
add wave -noupdate -label rst -radix hexadecimal /tb_regfile/rst
add wave -noupdate -label rd -radix hexadecimal /tb_regfile/rd
add wave -noupdate -label data -radix hexadecimal /tb_regfile/data
add wave -noupdate -label ra -radix hexadecimal /tb_regfile/ra
add wave -noupdate -label rb -radix hexadecimal /tb_regfile/rb
add wave -noupdate -label value_a -radix hexadecimal /tb_regfile/value_a
add wave -noupdate -label value_b -radix hexadecimal /tb_regfile/value_b
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 55
configure wave -timelineunits ns
update
after 2000 {wave zoom range 0ns 160ns}
