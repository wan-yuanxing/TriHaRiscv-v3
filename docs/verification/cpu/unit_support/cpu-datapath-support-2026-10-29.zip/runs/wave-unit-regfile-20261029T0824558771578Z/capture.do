onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-unit-regfile-20261029T0824558771578Z/regfile.vcd}
vcd add -r /*
run -all
quit -f -code 0
