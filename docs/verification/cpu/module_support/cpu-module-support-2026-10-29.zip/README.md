# CPU 模块级仿真支撑材料

本目录对应技术文档 B.3 的前端重定向和发射/旁路模块验证。

| 模块 | 正例结果 | 负例结果 |
|---|---|---|
| 前端重定向 | 4 次重定向、12 项交付、4 项迟到响应丢弃 | 未注册重定向版本触发 FRONTEND_FAIL |
| 发射/旁路 | 16 次发射、16 次退休、26 项操作数检查、38 周期 | 错误加载返回触发 ISSUE_FLOW_FAIL |

`module-run-index.json` 记录两组正例、两组负例的工具命令、源码/原语模型/输出 SHA-256 和截图时间窗口。`cpu-module-support-2026-10-29.zip` 包含实际 WLF/VCD、日志、显示脚本、测试台和依赖源码。

运行入口（CPU 工程根目录，Windows PowerShell）：

```powershell
pwsh -NoProfile -File scripts/cpu/capture_unit_waveforms.ps1 -Test frontend
pwsh -NoProfile -File scripts/cpu/capture_unit_waveforms.ps1 -Test issueflow
```

追加 `-Broken` 执行错误注入负例。正例返回 0，负例返回 1；判定同时检查 PASS/FAIL 标志和仿真日志，不能只看 ModelSim 退出码。

前端波形窗口为 0--300 ns，发射波形窗口为 140--340 ns。截图来自原生 ModelSim WLF 窗口，未重绘。
