#requires -Version 7.0
[CmdletBinding()]
param(
    [ValidateSet('mularith','divarith','csr','alu','regfile','frontend','issueflow')][string] $Test = 'mularith',
    [switch] $Broken,
    [string] $ModelSimBin = 'D:/modeltech64_2020.4/win64'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'simulation_common.ps1')
. (Join-Path $PSScriptRoot 'firmware_common.ps1')
$root = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$work = Join-Path $root ('build/cpu/wave-unit-' + $Test + '-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ'))
[IO.Directory]::CreateDirectory($work) | Out-Null
$modelsim = $ModelSimBin
$records = [Collections.Generic.List[object]]::new()
$result = [ordered]@{
    status='RUNNING'; test=$Test; broken=[bool]$Broken; directory=$work; source_unchanged=$false
    input_hashes=[ordered]@{}; external_hashes=[ordered]@{}; output_hashes=[ordered]@{}; commands=$records
    wlf=$null; transcript=$null; waveform_scope=$null; error=$null
}
$resultPath = Join-Path $work 'result.json'
Save-TrihaJson $resultPath $result

function Native([string] $Exe,[string[]] $CommandArguments,[string] $Label,[int] $Timeout=180) {
    Invoke-TrihaNative -Executable $Exe -CommandArguments $CommandArguments -RunDirectory $work `
        -Label $Label -Records $records -TimeoutSeconds $Timeout
}

try {
    Assert-TrihaAdaptation $root
    $filelist = switch ($Test) {
        'mularith' { @('rtl/cpu/triha_multiplier.v','tb/cpu/tb_multiplier_payload.v') }
        'divarith' { @('rtl/cpu/vendor/src/core/biriscv_divider.v','rtl/cpu/triha_divider.v','tb/cpu/tb_divider_arithmetic.v') }
        'csr' { @('rtl/cpu/vendor/src/core/biriscv_csr_regfile.v','rtl/cpu/triha_csr.v','tb/cpu/tb_csr_functional.v') }
        'alu' { @('rtl/cpu/vendor/src/core/biriscv_alu.v','tb/cpu/tb_alu_functional.v') }
        'regfile' { @('rtl/cpu/vendor/src/core/biriscv_regfile.v','rtl/cpu/triha_regfile.v','tb/cpu/tb_regfile.v') }
        {$_ -in @('frontend','issueflow')} {
            @(Get-Content (Join-Path $root 'config/cpu_sources.f') | ForEach-Object {$_.Trim()} |
                Where-Object {$_ -and -not $_.StartsWith('#') -and $_ -notlike 'tb/*' -and $_ -notlike 'rtl/cpu/vendor/tb/*'}) +
                @($(if($Test -eq 'frontend'){'tb/cpu/tb_frontend_redirect.v'}else{'tb/cpu/tb_issue_flow.v'}))
        }
    }
    $modelSources=@()
    if($Test -in @('regfile','frontend','issueflow')){
        $modelSources=@(Get-TrihaPrimitiveModels -Root $root -LocalHashes $result.input_hashes -ExternalHashes $result.external_hashes)
    }
    if($Test -in @('frontend','issueflow')){$result.input_hashes['config/cpu_sources.f']=Get-TrihaHash (Join-Path $root 'config/cpu_sources.f')}
    foreach ($relative in $filelist + @('rtl/cpu/vendor/src/core/biriscv_defs.v',
        'scripts/cpu/firmware_common.ps1',
        'rtl/cpu/ADAPTATIONS.json','scripts/cpu/capture_unit_waveforms.ps1',
        'scripts/cpu/run_modelsim.do')) {
        $result.input_hashes[$relative] = Get-TrihaHash (Join-Path $root $relative)
    }
    $result.waveform_scope = switch ($Test) {
        'mularith' { @('/tb_multiplier_payload/clk','/tb_multiplier_payload/rst','/tb_multiplier_payload/valid','/tb_multiplier_payload/hold','/tb_multiplier_payload/opcode','/tb_multiplier_payload/operand_a','/tb_multiplier_payload/operand_b','/tb_multiplier_payload/early_low','/tb_multiplier_payload/early_valid','/tb_multiplier_payload/result','/tb_multiplier_payload/valid_out') }
        'divarith' { @('/tb_divider_arithmetic/clk','/tb_divider_arithmetic/rst','/tb_divider_arithmetic/valid','/tb_divider_arithmetic/opcode','/tb_divider_arithmetic/a','/tb_divider_arithmetic/b','/tb_divider_arithmetic/golden_valid','/tb_divider_arithmetic/candidate_valid','/tb_divider_arithmetic/golden_value','/tb_divider_arithmetic/candidate_value') }
        'csr' { @('/tb_csr_functional/clk','/tb_csr_functional/rst','/tb_csr_functional/valid','/tb_csr_functional/opcode','/tb_csr_functional/operand','/tb_csr_functional/read_valid','/tb_csr_functional/read_value','/tb_csr_functional/wb_write','/tb_csr_functional/wb_addr','/tb_csr_functional/wb_data','/tb_csr_functional/trap','/tb_csr_functional/trap_pc','/tb_csr_functional/branch_valid','/tb_csr_functional/branch_pc') }
        'alu' { @('/tb_alu_functional/op','/tb_alu_functional/a','/tb_alu_functional/b','/tb_alu_functional/expected','/tb_alu_functional/result','/tb_alu_functional/check_ok') }
        'regfile' { @('/tb_regfile/clk','/tb_regfile/rst','/tb_regfile/rd','/tb_regfile/data','/tb_regfile/ra','/tb_regfile/rb','/tb_regfile/value_a','/tb_regfile/value_b') }
        'frontend' { @('/tb_frontend_redirect/clk','/tb_frontend_redirect/branch','/tb_frontend_redirect/target','/tb_frontend_redirect/pc','/tb_frontend_redirect/rd','/tb_frontend_redirect/pending','/tb_frontend_redirect/response','/tb_frontend_redirect/consume','/tb_frontend_redirect/valid0','/tb_frontend_redirect/pc0','/tb_frontend_redirect/dropped') }
        'issueflow' { @('/tb_issue_flow/clk','/tb_issue_flow/issue_pc','/tb_issue_flow/issue_fire','/tb_issue_flow/operand_a','/tb_issue_flow/operand_b','/tb_issue_flow/load_e1','/tb_issue_flow/load_e2','/tb_issue_flow/mul_e1','/tb_issue_flow/early_mul','/tb_issue_flow/pipe_stall','/tb_issue_flow/d_rd','/tb_issue_flow/d_accept','/tb_issue_flow/d_ack','/tb_issue_flow/wb_valid','/tb_issue_flow/wb_pc','/tb_issue_flow/wb_data') }
    }
    $waveDo = Join-Path $work 'capture.do'
    $vcdPath=(Join-Path $work "$Test.vcd").Replace('\','/')
    $lines = @('onerror {quit -f -code 2}','onbreak {quit -f -code 3}','log -r /*',
        "vcd file {$vcdPath}",'vcd add -r /*','run -all','quit -f -code 0')
    [IO.File]::WriteAllLines($waveDo,$lines,[Text.UTF8Encoding]::new($false))
    $result.input_hashes[$waveDo] = Get-TrihaHash $waveDo
    $viewDo=Join-Path $work 'view.do'
    $viewLines=@('view wave -undock -width 2560 -height 1392 -x 0 -y 0','font configure waveFont -family {Courier New} -size 20')
    foreach($signal in $result.waveform_scope){$label=($signal -split '/')[-1];$viewLines+="add wave -noupdate -label $label -radix hexadecimal $signal"}
    $viewLines+=@('configure wave -namecolwidth 320','configure wave -valuecolwidth 260','configure wave -rowmargin 55','configure wave -timelineunits ns','update','after 2000 {wave zoom range 0ns 160ns}')
    [IO.File]::WriteAllLines($viewDo,$viewLines,[Text.UTF8Encoding]::new($false))
    $result['view_do']=$viewDo
    Native (Join-Path $modelsim 'vmap.exe') @('-c') 'vmap' | Out-Null
    Native (Join-Path $modelsim 'vlib.exe') @('work') 'vlib' | Out-Null
    $vlog = @('-work','work',('+incdir+'+(Join-Path $root 'rtl/cpu/vendor/src/core')))
    if($Test -eq 'divarith'){$vlog+='+define+DIV_MODULE=triha_divider'}
    if($Test -eq 'regfile'){$vlog+='+define+RF_MODULE=triha_regfile'}
    if($Test -eq 'frontend'){$vlog+=('+define+CPU_FRONTEND_MODULE='+$(if($Broken){'biriscv_frontend'}else{'triha_frontend'}))}
    $vlog += @($filelist | ForEach-Object { Join-Path $root $_ })
    $vlog += $modelSources
    Native (Join-Path $modelsim 'vlog.exe') $vlog 'compile' | Out-Null
    $top = switch ($Test) { 'mularith' {'work.tb_multiplier_payload'} 'divarith' {'work.tb_divider_arithmetic'} 'csr' {'work.tb_csr_functional'} 'alu' {'work.tb_alu_functional'} 'regfile' {'work.tb_regfile'} 'frontend' {'work.tb_frontend_redirect'} 'issueflow' {'work.tb_issue_flow'} }
    $generic = if($Broken -and $Test -ne 'frontend'){if($Test -in @('divarith','regfile')){@('-gBROKEN=1')}else{@('-gCORRUPT_RESULT=1')}}else{@()}
    $wlf = Join-Path $work "$Test.wlf"
    $out = Native (Join-Path $modelsim 'vsim.exe') (@('-c','-l','batch-transcript.log','-wlf',$wlf,'-onfinish','exit','-voptargs=+acc') + $generic + @($top,'-do',$waveDo)) 'simulation' 180
    $result.transcript = Join-Path $work 'simulation.stdout.log'
    $result.wlf = $wlf
    $marker=switch($Test){mularith{'MUL_PAYLOAD_PASS'} divarith{'DIV_ARITH_PASS'} csr{'CSR_UNIT_PASS'} alu{'ALU_UNIT_PASS'} regfile{'REGFILE_PASS'} frontend{'FRONTEND_PASS'} issueflow{'ISSUE_FLOW_PASS'}}
    if ($out -notmatch $marker -or $out -match '\*\* (Error|Fatal)|_FAIL') { throw 'Expected unit PASS marker missing or a failure was reported.' }
    if(-not (Test-Path -LiteralPath $wlf) -or (Get-Item -LiteralPath $wlf).Length -eq 0){throw 'Raw WLF is missing or empty.'}
    $result['pass_line']=([regex]::Match($out,('(?m)^.*'+$marker+'.*$'))).Value.Trim()
    $result.status='PASS'
} catch {
    $result.status='FAIL'; $result.error=$_.Exception.Message
} finally {
    $result.source_unchanged=$true
    foreach ($relative in $result.input_hashes.Keys) {
        $path = if ([IO.Path]::IsPathRooted($relative)) { $relative } else { Join-Path $root $relative }
        if (-not (Test-Path -LiteralPath $path) -or (Get-TrihaHash $path) -ne $result.input_hashes[$relative]) { $result.source_unchanged=$false }
    }
    if(-not (Test-TrihaPrimitiveHashes $result.external_hashes)){$result.source_unchanged=$false}
    if(-not $result.source_unchanged){$result.status='FAIL';$result.error='Inputs changed during capture.'}
    foreach ($file in Get-ChildItem -LiteralPath $work -File) {
        if ($file.FullName -ne $resultPath) { $result.output_hashes[$file.Name] = Get-TrihaHash $file.FullName }
    }
    $result.runner_return_code = if ($result.status -eq 'PASS') { 0 } else { 1 }
    Save-TrihaJson $resultPath $result
    Write-Host "CPU_UNIT_WAVEFORM $($result.status) test=$Test result=$resultPath"
    if ($result.error) { Write-Host $result.error }
}
if ($result.status -eq 'PASS') { exit 0 } else { exit 1 }
