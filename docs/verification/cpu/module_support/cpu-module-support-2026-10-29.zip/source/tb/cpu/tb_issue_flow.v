/* Port-driven instruction stream; real issue/execute/multiply/LSU/RF state. */
`timescale 1ns / 1ps
module tb_issue_flow #(parameter integer CORRUPT_RESULT=0);
    reg clk=0, rst=1;
    always #5 clk=~clk;
    wire i_req, d_rd;
    wire [31:0] i_pc, d_addr, d_wdata;
    wire [3:0] d_wr;
    wire [10:0] d_req_tag;
    reg i_pending=0, i_valid=0;
    reg [31:0] i_saved=0;
    reg [63:0] i_data=0;
    reg d_waiting=0, d_pending=0, d_ack=0;
    reg [31:0] d_data=0;
    reg [10:0] d_saved_tag=0, d_resp_tag=0;
    integer accept_delay=0, response_delay=0, cycles=0;
    integer issued=0, retired=0, operand_checks=0, loads=0;
    integer accept_wait=0, load_wait=0, high_mul_wait=0;
    integer alu_e1_forward=0, early_mul_forward=0, newest_forward=0;
    integer issue_index, j;
    reg [31:0] model [0:31];
    reg [31:0] current_op;
    wire d_accept=d_waiting && accept_delay==0 && !d_pending;
    triha_cpu #(.SUPPORT_DUAL_ISSUE(0),.SUPPORT_SUPER(0),.SUPPORT_MMU(0),
        .SUPPORT_BRANCH_PREDICTION(0)) u_dut (
        .clk_i(clk),.rst_i(rst),.intr_i(1'b0),.reset_vector_i(32'h80000000),.cpu_id_i(32'b0),
        .mem_i_accept_i(!i_pending),.mem_i_valid_i(i_valid),.mem_i_error_i(1'b0),.mem_i_inst_i(i_data),
        .mem_i_rd_o(i_req),.mem_i_pc_o(i_pc),.mem_i_flush_o(),.mem_i_invalidate_o(),
        .mem_d_data_rd_i(d_data),.mem_d_accept_i(d_accept),.mem_d_ack_i(d_ack),
        .mem_d_error_i(1'b0),.mem_d_resp_tag_i(d_resp_tag),
        .mem_d_addr_o(d_addr),.mem_d_data_wr_o(d_wdata),.mem_d_rd_o(d_rd),.mem_d_wr_o(d_wr),
        .mem_d_req_tag_o(d_req_tag),.mem_d_cacheable_o(),.mem_d_invalidate_o(),
        .mem_d_writeback_o(),.mem_d_flush_o()
    );
    // Observers only: no force, deposits or hierarchical writes to the DUT.
    wire issue_fire=u_dut.u_issue.opcode_a_issue_r;
    wire [31:0] issue_pc=u_dut.u_issue.opcode0_pc_o;
    wire [31:0] operand_a=u_dut.u_issue.opcode0_ra_operand_o;
    wire [31:0] operand_b=u_dut.u_issue.opcode0_rb_operand_o;
    wire wb_valid=u_dut.u_issue.pipe0_valid_wb_w;
    wire [31:0] wb_pc=u_dut.u_issue.pipe0_pc_wb_w;
    wire [31:0] wb_data=u_dut.u_issue.pipe0_result_wb_w;
    wire [4:0] wb_rd=u_dut.u_issue.pipe0_rd_wb_w;
    wire load_e1=u_dut.u_issue.pipe0_load_e1_w;
    wire load_e2=u_dut.u_issue.pipe0_load_e2_w;
    wire mul_e1=u_dut.u_issue.pipe0_mul_e1_w;
    wire early_mul=u_dut.u_issue.pipe0_early_mul_w;
    wire pipe_stall=u_dut.u_issue.stall_w;

    function [31:0] instruction;
        input integer n;
        begin
            case(n)
                0: instruction=32'h00700093; // ADDI x1,x0,7
                1: instruction=32'h00908113; // ADDI x2,x1,9
                2: instruction=32'h001101b3; // ADD x3,x2,x1
                3: instruction=32'h00002203; // LW x4,0(x0)
                4: instruction=32'h003202b3; // ADD x5,x4,x3
                5: instruction=32'h02208333; // MUL x6,x1,x2
                6: instruction=32'h001303b3; // ADD x7,x6,x1
                7: instruction=32'h02209433; // MULH x8,x1,x2
                8: instruction=32'h007404b3; // ADD x9,x8,x7
                9: instruction=32'h06300013; // ADDI x0,x0,99
                10: instruction=32'h00900533; // ADD x10,x0,x9
                11: instruction=32'h00150593; // ADDI x11,x10,1
                12: instruction=32'h00258633; // ADD x12,x11,x2
                13: instruction=32'h00160633; // ADD x12,x12,x1
                14: instruction=32'h00c606b3; // ADD x13,x12,x12
                15: instruction=32'h00168713; // ADDI x14,x13,1
                default: instruction=32'h0000006f; // JAL x0,0
            endcase
        end
    endfunction
    function [31:0] expected_value;
        input integer n;
        begin
            case(n)
                0: expected_value=7; 1: expected_value=16; 2: expected_value=23;
                3: expected_value=32'h12345678; 4: expected_value=32'h1234568f;
                5: expected_value=112; 6: expected_value=119; 7: expected_value=0;
                8: expected_value=119; 9: expected_value=99; 10: expected_value=119;
                11: expected_value=120; 12: expected_value=136; 13: expected_value=143;
                14: expected_value=286; 15: expected_value=287;
                default: expected_value=0;
            endcase
        end
    endfunction
    always @(posedge clk) begin
        if(rst) begin i_pending<=0; i_valid<=0; d_waiting<=0; d_pending<=0; d_ack<=0; end
        else begin
            i_valid<=0;
            if(i_req && !i_pending) begin i_pending<=1; i_saved<=i_pc; end
            if(i_pending) begin
                i_data<={instruction((i_saved-32'h80000000)/4+1),instruction((i_saved-32'h80000000)/4)};
                i_valid<=1; i_pending<=0;
            end
            d_ack<=0;
            if(d_rd && !d_pending) begin
                if(!d_waiting) begin d_waiting<=1; accept_delay<=3; end
                else if(accept_delay>0) begin accept_delay<=accept_delay-1; accept_wait=accept_wait+1; end
                else begin
                    if(d_addr!==0 || d_wr!==0) $fatal(1,"ISSUE_FLOW_FAIL load_request");
                    d_pending<=1; d_waiting<=0; response_delay<=4; d_saved_tag<=d_req_tag; loads=loads+1;
                end
            end
            if(d_pending) begin
                if(response_delay>0) response_delay<=response_delay-1;
                else begin
                    d_ack<=1; d_pending<=0; d_resp_tag<=d_saved_tag;
                    d_data<=CORRUPT_RESULT ? 32'h12345679 : 32'h12345678;
                end
            end
        end
    end
    always @(posedge clk) if(!rst) begin
        cycles=cycles+1;
        if(cycles>1000) $fatal(1,"ISSUE_FLOW_FAIL timeout");
        if(d_wr!=0) $fatal(1,"ISSUE_FLOW_FAIL unexpected_store");
        if(u_dut.u_issue.csr_writeback_exception_o!=0) $fatal(1,"ISSUE_FLOW_FAIL exception");
        if(!issue_fire && issued==4 && (load_e1||load_e2)) load_wait=load_wait+1;
        if(!issue_fire && issued==8 && mul_e1) high_mul_wait=high_mul_wait+1;
        if(issue_fire && issue_pc>=32'h80000000 && issue_pc<32'h80000040) begin
            issue_index=(issue_pc-32'h80000000)/4; current_op=instruction(issue_index);
            if(issue_index!=issued || u_dut.u_issue.opcode0_opcode_o!==current_op)
                $fatal(1,"ISSUE_FLOW_FAIL issue_order pc=%h expected_index=%0d",issue_pc,issued);
            if(operand_a!==model[current_op[19:15]])
                $fatal(1,"ISSUE_FLOW_FAIL rs1 pc=%h expected=%h actual=%h",issue_pc,model[current_op[19:15]],operand_a);
            operand_checks=operand_checks+1;
            if(current_op[6:0]==7'h33) begin
                if(operand_b!==model[current_op[24:20]])
                    $fatal(1,"ISSUE_FLOW_FAIL rs2 pc=%h expected=%h actual=%h",issue_pc,model[current_op[24:20]],operand_b);
                operand_checks=operand_checks+1;
            end
            if(issue_index==1 && u_dut.u_issue.pipe0_rd_e1_w==1) alu_e1_forward=alu_e1_forward+1;
            if(issue_index==6 && mul_e1 && early_mul) early_mul_forward=early_mul_forward+1;
            if(issue_index==14 && u_dut.u_issue.pipe0_rd_e1_w==12 && u_dut.u_issue.pipe0_rd_bypass_e2_w==12)
                newest_forward=newest_forward+1;
            if(current_op[11:7]!=0) model[current_op[11:7]]=expected_value(issue_index);
            issued=issued+1;
            $display("ISSUE_FLOW_ISSUE pc=%h op=%h ra=%h rb=%h",issue_pc,current_op,operand_a,operand_b);
        end
        if(wb_valid && retired<16) begin
            current_op=instruction(retired);
            if(wb_pc!==(32'h80000000+retired*4) || u_dut.u_issue.pipe0_opc_wb_w!==current_op || wb_rd!==current_op[11:7])
                $fatal(1,"ISSUE_FLOW_FAIL retirement_order pc=%h index=%0d rd=%0d",wb_pc,retired,wb_rd);
            if(wb_rd!=0 && wb_data!==expected_value(retired))
                $fatal(1,"ISSUE_FLOW_FAIL wb pc=%h expected=%h actual=%h",wb_pc,expected_value(retired),wb_data);
            retired=retired+1;
            $display("ISSUE_FLOW_WB pc=%h rd=%0d value=%h",wb_pc,wb_rd,wb_data);
            if(retired==16) begin
                if(issued!=16 || loads!=1 || accept_wait==0 || load_wait==0 || high_mul_wait==0 ||
                    alu_e1_forward!=1 || early_mul_forward!=1 || newest_forward!=1)
                    $fatal(1,"ISSUE_FLOW_FAIL coverage issue=%0d load=%0d accept_wait=%0d load_wait=%0d high_wait=%0d alu=%0d early=%0d newest=%0d",issued,loads,accept_wait,load_wait,high_mul_wait,alu_e1_forward,early_mul_forward,newest_forward);
                $display("ISSUE_FLOW_PASS issued=%0d retired=%0d operands=%0d loads=%0d accept_wait=%0d load_wait=%0d high_mul_wait=%0d alu_e1=%0d early_mul=%0d newest=%0d cycles=%0d",issued,retired,operand_checks,loads,accept_wait,load_wait,high_mul_wait,alu_e1_forward,early_mul_forward,newest_forward,cycles);
                $finish;
            end
        end
    end
    initial begin for(j=0;j<32;j=j+1) model[j]=0; repeat(5) @(negedge clk); #1; rst=0; end
endmodule
