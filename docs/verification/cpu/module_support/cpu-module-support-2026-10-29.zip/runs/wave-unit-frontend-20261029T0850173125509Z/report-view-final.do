view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_frontend_redirect/clk
add wave -noupdate -label branch -radix hexadecimal /tb_frontend_redirect/branch
add wave -noupdate -label target -radix hexadecimal /tb_frontend_redirect/target
add wave -noupdate -label pc -radix hexadecimal /tb_frontend_redirect/pc
add wave -noupdate -label rd -radix hexadecimal /tb_frontend_redirect/rd
add wave -noupdate -label pending -radix hexadecimal /tb_frontend_redirect/pending
add wave -noupdate -label response -radix hexadecimal /tb_frontend_redirect/response
add wave -noupdate -label consume -radix hexadecimal /tb_frontend_redirect/consume
add wave -noupdate -label valid0 -radix hexadecimal /tb_frontend_redirect/valid0
add wave -noupdate -label pc0 -radix hexadecimal /tb_frontend_redirect/pc0
add wave -noupdate -label dropped -radix hexadecimal /tb_frontend_redirect/dropped
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 55
configure wave -timelineunits ns
update
after 2000 {wave zoom range 0ns 300ns}
