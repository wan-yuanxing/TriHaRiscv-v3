view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_issue_flow/clk
add wave -noupdate -label issue_pc -radix hexadecimal /tb_issue_flow/issue_pc
add wave -noupdate -label issue_fire -radix hexadecimal /tb_issue_flow/issue_fire
add wave -noupdate -label operand_a -radix hexadecimal /tb_issue_flow/operand_a
add wave -noupdate -label operand_b -radix hexadecimal /tb_issue_flow/operand_b
add wave -noupdate -label load_e1 -radix hexadecimal /tb_issue_flow/load_e1
add wave -noupdate -label load_e2 -radix hexadecimal /tb_issue_flow/load_e2
add wave -noupdate -label mul_e1 -radix hexadecimal /tb_issue_flow/mul_e1
add wave -noupdate -label early_mul -radix hexadecimal /tb_issue_flow/early_mul
add wave -noupdate -label pipe_stall -radix hexadecimal /tb_issue_flow/pipe_stall
add wave -noupdate -label d_rd -radix hexadecimal /tb_issue_flow/d_rd
add wave -noupdate -label d_accept -radix hexadecimal /tb_issue_flow/d_accept
add wave -noupdate -label d_ack -radix hexadecimal /tb_issue_flow/d_ack
add wave -noupdate -label wb_valid -radix hexadecimal /tb_issue_flow/wb_valid
add wave -noupdate -label wb_pc -radix hexadecimal /tb_issue_flow/wb_pc
add wave -noupdate -label wb_data -radix hexadecimal /tb_issue_flow/wb_data
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 55
configure wave -timelineunits ns
update
after 2000 {wave zoom range 0ns 160ns}
