onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-unit-lsufunctional-20261029T1031435610458Z/lsufunctional.vcd}
vcd add -r /*
run -all
quit -f -code 0
