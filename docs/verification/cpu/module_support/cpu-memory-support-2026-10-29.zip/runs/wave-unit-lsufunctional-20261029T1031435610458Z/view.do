view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_lsu_functional/clk
add wave -noupdate -label valid -radix hexadecimal /tb_lsu_functional/valid
add wave -noupdate -label opcode -radix hexadecimal /tb_lsu_functional/opcode
add wave -noupdate -label address -radix hexadecimal /tb_lsu_functional/address
add wave -noupdate -label request_read -radix hexadecimal /tb_lsu_functional/request_read
add wave -noupdate -label request_write -radix hexadecimal /tb_lsu_functional/request_write
add wave -noupdate -label store_data -radix hexadecimal /tb_lsu_functional/store_data
add wave -noupdate -label accept -radix hexadecimal /tb_lsu_functional/accept
add wave -noupdate -label ack -radix hexadecimal /tb_lsu_functional/ack
add wave -noupdate -label wb_valid -radix hexadecimal /tb_lsu_functional/wb_valid
add wave -noupdate -label wb_value -radix hexadecimal /tb_lsu_functional/wb_value
add wave -noupdate -label exception -radix hexadecimal /tb_lsu_functional/exception
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 55
configure wave -timelineunits ns
update
after 2000 {wave zoom range 0ns 160ns}
