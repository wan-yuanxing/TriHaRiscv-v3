view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_dcache_writeback/clk
add wave -noupdate -label rst_n -radix hexadecimal /tb_cpu_dcache_writeback/rst_n
add wave -noupdate -label addr -radix hexadecimal /tb_cpu_dcache_writeback/addr
add wave -noupdate -label mask -radix hexadecimal /tb_cpu_dcache_writeback/mask
add wave -noupdate -label rd -radix hexadecimal /tb_cpu_dcache_writeback/rd
add wave -noupdate -label clean -radix hexadecimal /tb_cpu_dcache_writeback/clean
add wave -noupdate -label lower_rd -radix hexadecimal /tb_cpu_dcache_writeback/lower_rd
add wave -noupdate -label lower_wr -radix hexadecimal /tb_cpu_dcache_writeback/lower_wr
add wave -noupdate -label lower_ack -radix hexadecimal /tb_cpu_dcache_writeback/lower_ack
add wave -noupdate -label ack -radix hexadecimal /tb_cpu_dcache_writeback/ack
add wave -noupdate -label error -radix hexadecimal /tb_cpu_dcache_writeback/error
add wave -noupdate -label resp_tag -radix hexadecimal /tb_cpu_dcache_writeback/resp_tag
add wave -noupdate -label reads -radix hexadecimal /tb_cpu_dcache_writeback/reads
add wave -noupdate -label writes -radix hexadecimal /tb_cpu_dcache_writeback/writes
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 35
configure wave -timelineunits ns
update
after 2000 {wave zoom full}
