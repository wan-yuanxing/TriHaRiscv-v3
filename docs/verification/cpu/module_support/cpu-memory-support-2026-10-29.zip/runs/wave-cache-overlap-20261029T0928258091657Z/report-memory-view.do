view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_dcache_overlap/clk
add wave -noupdate -label score_active -radix hexadecimal /tb_cpu_dcache_overlap/score_active
add wave -noupdate -label addr -radix hexadecimal /tb_cpu_dcache_overlap/addr
add wave -noupdate -label rd -radix hexadecimal /tb_cpu_dcache_overlap/rd
add wave -noupdate -label accept -radix hexadecimal /tb_cpu_dcache_overlap/accept
add wave -noupdate -label ack -radix hexadecimal /tb_cpu_dcache_overlap/ack
add wave -noupdate -label tag -radix hexadecimal /tb_cpu_dcache_overlap/tag
add wave -noupdate -label resp_tag -radix hexadecimal /tb_cpu_dcache_overlap/resp_tag
add wave -noupdate -label rdata -radix hexadecimal /tb_cpu_dcache_overlap/rdata
add wave -noupdate -label lower_rd -radix hexadecimal /tb_cpu_dcache_overlap/lower_rd
add wave -noupdate -label error -radix hexadecimal /tb_cpu_dcache_overlap/error
add wave -noupdate -label head -radix unsigned /tb_cpu_dcache_overlap/head
add wave -noupdate -label tail -radix unsigned /tb_cpu_dcache_overlap/tail
configure wave -namecolwidth 320
configure wave -valuecolwidth 330
configure wave -rowmargin 45
configure wave -timelineunits ns
update
after 2000 {wave zoom range 3690ns 3970ns}
