onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-cache-overlap-20261029T0928258091657Z/overlap.vcd}
vcd add -r /*
run -all
quit -f -code 0
