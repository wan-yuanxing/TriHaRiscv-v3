view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_cache/clk
add wave -noupdate -label rst_n -radix hexadecimal /tb_cpu_cache/rst_n
add wave -noupdate -label i_req -radix hexadecimal /tb_cpu_cache/i_req
add wave -noupdate -label i_pending -radix hexadecimal /tb_cpu_cache/i_pending
add wave -noupdate -label arvalid -radix hexadecimal /tb_cpu_cache/arvalid
add wave -noupdate -label rvalid -radix hexadecimal /tb_cpu_cache/rvalid
add wave -noupdate -label rready -radix hexadecimal /tb_cpu_cache/rready
add wave -noupdate -label d_addr -radix hexadecimal /tb_cpu_cache/d_addr
add wave -noupdate -label d_rd -radix hexadecimal /tb_cpu_cache/d_rd
add wave -noupdate -label d_accept -radix hexadecimal /tb_cpu_cache/d_accept
add wave -noupdate -label p_rd -radix hexadecimal /tb_cpu_cache/p_rd
add wave -noupdate -label p_ack -radix hexadecimal /tb_cpu_cache/p_ack
add wave -noupdate -label d_ack -radix hexadecimal /tb_cpu_cache/d_ack
add wave -noupdate -label d_error -radix hexadecimal /tb_cpu_cache/d_error
add wave -noupdate -label d_reads -radix hexadecimal /tb_cpu_cache/d_reads
add wave -noupdate -label d_writes -radix hexadecimal /tb_cpu_cache/d_writes
configure wave -namecolwidth 320
configure wave -valuecolwidth 260
configure wave -rowmargin 35
configure wave -timelineunits ns
update
after 2000 {wave zoom full}
