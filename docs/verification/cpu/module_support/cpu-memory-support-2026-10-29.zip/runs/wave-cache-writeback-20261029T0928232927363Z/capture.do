onerror {quit -f -code 2}
onbreak {quit -f -code 3}
log -r /*
vcd file {D:/FPGA/TriHaRiscv-cpu-windows/build/cpu/wave-cache-writeback-20261029T0928232927363Z/writeback.vcd}
vcd add -r /*
run -all
quit -f -code 0
