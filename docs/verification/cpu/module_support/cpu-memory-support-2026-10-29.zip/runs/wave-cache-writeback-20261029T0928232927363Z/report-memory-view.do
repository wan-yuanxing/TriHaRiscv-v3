view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_dcache_writeback/clk
add wave -noupdate -label addr -radix hexadecimal /tb_cpu_dcache_writeback/addr
add wave -noupdate -label mask -radix hexadecimal /tb_cpu_dcache_writeback/mask
add wave -noupdate -label wdata -radix hexadecimal /tb_cpu_dcache_writeback/wdata
add wave -noupdate -label rd -radix hexadecimal /tb_cpu_dcache_writeback/rd
add wave -noupdate -label rdata -radix hexadecimal /tb_cpu_dcache_writeback/rdata
add wave -noupdate -label clean -radix hexadecimal /tb_cpu_dcache_writeback/clean
add wave -noupdate -label lower_rd -radix hexadecimal /tb_cpu_dcache_writeback/lower_rd
add wave -noupdate -label lower_wr -radix hexadecimal /tb_cpu_dcache_writeback/lower_wr
add wave -noupdate -label lower_addr -radix hexadecimal /tb_cpu_dcache_writeback/lower_addr
add wave -noupdate -label lower_data -radix hexadecimal /tb_cpu_dcache_writeback/lower_data
add wave -noupdate -label lower_ack -radix hexadecimal /tb_cpu_dcache_writeback/lower_ack
add wave -noupdate -label ack -radix hexadecimal /tb_cpu_dcache_writeback/ack
add wave -noupdate -label error -radix hexadecimal /tb_cpu_dcache_writeback/error
add wave -noupdate -label reads -radix unsigned /tb_cpu_dcache_writeback/reads
add wave -noupdate -label writes -radix unsigned /tb_cpu_dcache_writeback/writes
configure wave -namecolwidth 320
configure wave -valuecolwidth 330
configure wave -rowmargin 30
configure wave -timelineunits ns
update
after 2000 {wave zoom range 2920ns 4140ns}
