view wave -undock -width 2560 -height 1392 -x 0 -y 0
font configure waveFont -family {Courier New} -size 20
add wave -noupdate -label clk -radix hexadecimal /tb_cpu_cache/clk
add wave -noupdate -label i_req -radix hexadecimal /tb_cpu_cache/i_req
add wave -noupdate -label i_addr -radix hexadecimal /tb_cpu_cache/i_addr
add wave -noupdate -label i_accept -radix hexadecimal /tb_cpu_cache/i_accept
add wave -noupdate -label arvalid -radix hexadecimal /tb_cpu_cache/arvalid
add wave -noupdate -label araddr -radix hexadecimal /tb_cpu_cache/araddr
add wave -noupdate -label rvalid -radix hexadecimal /tb_cpu_cache/rvalid
add wave -noupdate -label rlast -radix hexadecimal /tb_cpu_cache/rlast
add wave -noupdate -label i_valid -radix hexadecimal /tb_cpu_cache/i_valid
add wave -noupdate -label i_data -radix hexadecimal /tb_cpu_cache/i_data
add wave -noupdate -label i_error -radix hexadecimal /tb_cpu_cache/i_error
add wave -noupdate -label i_reads -radix unsigned /tb_cpu_cache/i_reads
add wave -noupdate -label i_hits -radix unsigned /tb_cpu_cache/i_hits
configure wave -namecolwidth 320
configure wave -valuecolwidth 330
configure wave -rowmargin 45
configure wave -timelineunits ns
update
after 2000 {wave zoom range 2580ns 3260ns}
