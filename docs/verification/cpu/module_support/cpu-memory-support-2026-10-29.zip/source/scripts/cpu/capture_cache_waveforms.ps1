#requires -Version 7.0
[CmdletBinding()]
param(
    [ValidateSet('components','writeback','overlap')][string] $Test='components',
    [switch] $Broken,
    [string] $ModelSimBin='D:/modeltech64_2020.4/win64'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'simulation_common.ps1')
. (Join-Path $PSScriptRoot 'firmware_common.ps1')
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$work=Join-Path $root ('build/cpu/wave-cache-'+$Test+'-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ'))
[IO.Directory]::CreateDirectory($work)|Out-Null
$records=[Collections.Generic.List[object]]::new()
$result=[ordered]@{status='RUNNING';test=$Test;broken=[bool]$Broken;directory=$work;input_hashes=[ordered]@{};external_hashes=[ordered]@{};output_hashes=[ordered]@{};commands=$records;source_unchanged=$false;wlf=$null;transcript=$null;waveform_scope=$null;error=$null}
$resultPath=Join-Path $work 'result.json';Save-TrihaJson $resultPath $result
function Native([string]$Exe,[string[]]$CommandArguments,[string]$Label){Invoke-TrihaNative -Executable $Exe -CommandArguments $CommandArguments -RunDirectory $work -Label $Label -Records $records -TimeoutSeconds 180}
try {
    $sources=@(Get-Content (Join-Path $root 'config/cpu_cache_sources.f')|ForEach-Object{$_.Trim()}|Where-Object{$_ -and -not $_.StartsWith('#')})
    $tb=switch($Test){components{'tb/cpu/tb_cpu_cache.v'}writeback{'tb/cpu/tb_cpu_dcache_writeback.v'}overlap{'tb/cpu/tb_cpu_dcache_overlap.v'}}
    $result.waveform_scope=switch($Test){
        components {@('/tb_cpu_cache/clk','/tb_cpu_cache/rst_n','/tb_cpu_cache/i_req','/tb_cpu_cache/i_pending','/tb_cpu_cache/arvalid','/tb_cpu_cache/rvalid','/tb_cpu_cache/rready','/tb_cpu_cache/d_addr','/tb_cpu_cache/d_rd','/tb_cpu_cache/d_accept','/tb_cpu_cache/p_rd','/tb_cpu_cache/p_ack','/tb_cpu_cache/d_ack','/tb_cpu_cache/d_error','/tb_cpu_cache/d_reads','/tb_cpu_cache/d_writes')}
        writeback {@('/tb_cpu_dcache_writeback/clk','/tb_cpu_dcache_writeback/rst_n','/tb_cpu_dcache_writeback/addr','/tb_cpu_dcache_writeback/mask','/tb_cpu_dcache_writeback/rd','/tb_cpu_dcache_writeback/clean','/tb_cpu_dcache_writeback/lower_rd','/tb_cpu_dcache_writeback/lower_wr','/tb_cpu_dcache_writeback/lower_ack','/tb_cpu_dcache_writeback/ack','/tb_cpu_dcache_writeback/error','/tb_cpu_dcache_writeback/resp_tag','/tb_cpu_dcache_writeback/reads','/tb_cpu_dcache_writeback/writes')}
        overlap {@('/tb_cpu_dcache_overlap/clk','/tb_cpu_dcache_overlap/rst_n','/tb_cpu_dcache_overlap/addr','/tb_cpu_dcache_overlap/rd','/tb_cpu_dcache_overlap/mask','/tb_cpu_dcache_overlap/lower_rd','/tb_cpu_dcache_overlap/lower_ack','/tb_cpu_dcache_overlap/accept','/tb_cpu_dcache_overlap/ack','/tb_cpu_dcache_overlap/error','/tb_cpu_dcache_overlap/resp_tag','/tb_cpu_dcache_overlap/reads','/tb_cpu_dcache_overlap/writes','/tb_cpu_dcache_overlap/score_active')}
    }
    foreach($name in $sources+$tb+@('config/cpu_cache_sources.f','config/cpu_cache.json','scripts/cpu/capture_cache_waveforms.ps1','scripts/cpu/firmware_common.ps1','scripts/cpu/run_modelsim.do','rtl/cpu/CACHE_ADAPTATIONS.json')){$path=Join-Path $root $name;if(Test-Path $path){$result.input_hashes[$name]=Get-TrihaHash $path}}
    $waveDo=Join-Path $work 'capture.do';$vcd=(Join-Path $work "$Test.vcd").Replace('\','/')
    [IO.File]::WriteAllLines($waveDo,@('onerror {quit -f -code 2}','onbreak {quit -f -code 3}','log -r /*',"vcd file {$vcd}",'vcd add -r /*','run -all','quit -f -code 0'),[Text.UTF8Encoding]::new($false));$result.input_hashes[$waveDo]=Get-TrihaHash $waveDo
    $viewDo=Join-Path $work 'view.do';$view=@('view wave -undock -width 2560 -height 1392 -x 0 -y 0','font configure waveFont -family {Courier New} -size 20');foreach($signal in $result.waveform_scope){$label=($signal-split'/')[-1];$view+="add wave -noupdate -label $label -radix hexadecimal $signal"};$view+=@('configure wave -namecolwidth 320','configure wave -valuecolwidth 260','configure wave -rowmargin 35','configure wave -timelineunits ns','update','after 2000 {wave zoom full}');[IO.File]::WriteAllLines($viewDo,$view,[Text.UTF8Encoding]::new($false));$result.view_do=$viewDo
    Native (Join-Path $ModelSimBin 'vmap.exe') @('-c') 'vmap'|Out-Null;Native (Join-Path $ModelSimBin 'vlib.exe') @('work') 'vlib'|Out-Null
    $include='+incdir+'+(Join-Path $root 'rtl/cpu/vendor/src/core');Native (Join-Path $ModelSimBin 'vlog.exe') (@('-work','work',$include)+@($sources+$tb|ForEach-Object{Join-Path $root $_})) 'compile'|Out-Null
    $generic=@('-gCORRUPT_DATA='+[int][bool]$Broken);$top='work.'+[IO.Path]::GetFileNameWithoutExtension($tb)
    $out=Native (Join-Path $ModelSimBin 'vsim.exe') (@('-c','-l','batch-transcript.log','-wlf',(Join-Path $work "$Test.wlf"),'-onfinish','exit','-voptargs=+acc')+$generic+@($top,'-do',$waveDo)) 'simulation'
    $result.wlf=Join-Path $work "$Test.wlf";$result.transcript=Join-Path $work 'simulation.stdout.log';$marker=switch($Test){components{'CPU_CACHE_PASS'}writeback{'CPU_DCACHE_WB_PASS'}overlap{'CPU_DCACHE_OVERLAP_PASS'}}
    if($out-notmatch$marker-or$out-match'CPU_(CACHE|DCACHE)_(FAIL)|\*\* (Error|Fatal)'){throw 'Cache self-check marker missing or failure reported'}
    if(-not(Test-Path $result.wlf)){throw 'WLF missing'};$result.pass_line=([regex]::Match($out,'(?m)^.*'+$marker+'.*$')).Value.Trim();$result.status='PASS'
}catch{$result.status='FAIL';$result.error=$_.Exception.Message}finally{$result.source_unchanged=$true;foreach($name in $result.input_hashes.Keys){$path=if([IO.Path]::IsPathRooted($name)){$name}else{Join-Path $root $name};if(-not(Test-Path $path)-or(Get-TrihaHash $path)-ne$result.input_hashes[$name]){$result.source_unchanged=$false}};if(-not$result.source_unchanged){$result.status='FAIL';$result.error='Inputs changed'};foreach($file in Get-ChildItem -File $work){if($file.FullName-ne$resultPath){$result.output_hashes[$file.Name]=Get-TrihaHash $file.FullName}};$result.runner_return_code=if($result.status-eq'PASS'){0}else{1};Save-TrihaJson $resultPath $result;Write-Host "CPU_CACHE_WAVEFORM $($result.status) test=$Test result=$resultPath";if($result.error){Write-Host $result.error}}
if($result.status-eq'PASS'){exit 0}else{exit 1}
