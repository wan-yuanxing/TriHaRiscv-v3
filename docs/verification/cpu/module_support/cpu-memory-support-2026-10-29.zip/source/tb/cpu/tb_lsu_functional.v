/* Port-only LSU format, request-hold and completion/exception checks. */
`timescale 1ns / 1ps
`include "biriscv_defs.v"
module tb_lsu_functional #(parameter integer CORRUPT_RESULT=0);
    reg clk=0,rst=1,valid=0,accept=0,ack=0,error=0;
    reg [31:0] opcode=32'h13,source_a=0,source_b=0,return_data=0;
    wire [31:0] address,store_data,wb_value,bypass;
    wire request_read,cacheable,wb_valid,stall;
    wire [3:0] request_write;
    wire [10:0] tag;
    wire [5:0] exception;
    integer checks=0,operations=0,held_cycles=0,loads=0,stores=0,alignment_faults=0,bus_faults=0,n;
    always #5 clk=~clk;
    triha_lsu u_dut (
        .clk_i(clk),.rst_i(rst),.opcode_valid_i(valid),.opcode_opcode_i(opcode),
        .opcode_pc_i(32'h80000000),.opcode_invalid_i(1'b0),.opcode_rd_idx_i(5'd5),
        .opcode_ra_idx_i(5'd1),.opcode_rb_idx_i(5'd2),.opcode_ra_operand_i(source_a),.opcode_rb_operand_i(source_b),
        .mem_data_rd_i(return_data),.mem_accept_i(accept),.mem_ack_i(ack),.mem_error_i(error),
        .mem_resp_tag_i(11'b0),.mem_load_fault_i(1'b0),.mem_store_fault_i(1'b0),
        .mem_addr_o(address),.mem_data_wr_o(store_data),.mem_rd_o(request_read),.mem_wr_o(request_write),
        .mem_cacheable_o(cacheable),.mem_req_tag_o(tag),.mem_invalidate_o(),.mem_writeback_o(),.mem_flush_o(),
        .writeback_valid_o(wb_valid),.writeback_value_o(wb_value),.writeback_bypass_o(bypass),
        .writeback_exception_o(exception),.stall_o(stall)
    );
    task check;
        input good; input [319:0] why;
        begin checks=checks+1;if(good!==1'b1)$fatal(1,"LSU_UNIT_FAIL %0s op=%h address=%h wb=%h exception=%h",why,opcode,address,wb_value,exception);end
    endtask
    function [31:0] encode;
        input integer kind;input [11:0] offset;
        reg [31:0] base;
        begin
            case(kind)
                0:base=`INST_LW;1:base=`INST_LB;2:base=`INST_LBU;3:base=`INST_LH;4:base=`INST_LHU;
                5:base=`INST_SB;6:base=`INST_SH;default:base=`INST_SW;
            endcase
            if(kind<5)encode=base|{offset,20'b0}|32'h00008280;
            else encode=base|{offset[11:5],25'b0}|{20'b0,offset[4:0],7'b0}|32'h00208000;
        end
    endfunction
    task access;
        input integer kind;input [11:0] offset;
        input [31:0] expected;input [3:0] mask;input [31:0] expected_store;
        input [5:0] expected_exception;
        reg unaligned;reg [31:0] fault_address;integer guard,k;
        begin
            unaligned=expected_exception==`EXCEPTION_MISALIGNED_LOAD||expected_exception==`EXCEPTION_MISALIGNED_STORE;
            fault_address=32'h80001000+offset;
            @(negedge clk);#1;check(!stall,"previous access drained");
            valid=1;opcode=encode(kind,offset);source_a=32'h80001000;source_b=32'haabbccdd;
            @(negedge clk);#1;valid=0;opcode=32'h13;source_a=0;source_b=0;
            if(unaligned)begin
                guard=0;
                while(!wb_valid)begin check(!request_read&&request_write==0,"unaligned request suppressed");@(negedge clk);#1;guard=guard+1;if(guard>8)$fatal(1,"LSU_UNIT_FAIL unaligned timeout");end
                check(exception===expected_exception&&wb_value===fault_address,"precise unaligned completion");
                alignment_faults=alignment_faults+1;
            end else begin
                for(k=0;k<3;k=k+1)begin
                    check(address==={fault_address[31:2],2'b0},"held aligned address");
                    check(request_read===(kind<5)&&request_write===mask,"held read and byte masks");
                    if(kind>=5)check(store_data===expected_store,"store byte placement");
                    check(stall&&!wb_valid&&cacheable&&tag==0,"unaccepted request control");
                    held_cycles=held_cycles+1;@(negedge clk);#1;
                end
                accept=1;@(negedge clk);#1;accept=0;
                repeat(2)@(negedge clk);#1;
                return_data=32'h80ff7f01^CORRUPT_RESULT;error=expected_exception!=0;ack=1;#1;
                check(wb_valid&&exception===expected_exception,"completion valid and exception");
                if(expected_exception!=0)begin check(wb_value===fault_address,"precise bus fault address");bus_faults=bus_faults+1;end
                else if(kind<5)check(wb_value===expected,"load byte halfword sign extension");
                else check(wb_value===0,"store completion payload");
                if(kind<5)loads=loads+1;else stores=stores+1;
            end
            operations=operations+1;@(negedge clk);#1;ack=0;error=0;
            @(negedge clk);#1;check(!wb_valid,"single completion pulse");
        end
    endtask
    initial begin
        repeat(5)@(negedge clk);#1;rst=0;
        access(1,0,1,0,0,0);
        access(1,1,32'h7f,0,0,0);
        access(1,2,32'hffffffff,0,0,0);
        access(1,3,32'hffffff80,0,0,0);
        access(2,2,32'hff,0,0,0);
        access(2,3,32'h80,0,0,0);
        access(3,0,32'h7f01,0,0,0);
        access(3,2,32'hffff80ff,0,0,0);
        access(4,2,32'h80ff,0,0,0);
        access(0,0,32'h80ff7f01,0,0,0);
        access(5,3,0,4'b1000,32'hdd000000,0);
        access(6,2,0,4'b1100,32'hccdd0000,0);
        access(7,0,0,4'b1111,32'haabbccdd,0);
        access(3,1,0,0,0,`EXCEPTION_MISALIGNED_LOAD);
        access(0,2,0,0,0,`EXCEPTION_MISALIGNED_LOAD);
        access(7,1,0,0,0,`EXCEPTION_MISALIGNED_STORE);
        access(0,0,0,0,0,`EXCEPTION_FAULT_LOAD);
        access(7,0,0,4'b1111,32'haabbccdd,`EXCEPTION_FAULT_STORE);
        check(operations==18&&loads==11&&stores==4&&alignment_faults==3&&bus_faults==2,"coverage");
        $display("LSU_UNIT_PASS operations=%0d checks=%0d held=%0d loads=%0d stores=%0d alignment_faults=%0d bus_faults=%0d",operations,checks,held_cycles,loads,stores,alignment_faults,bus_faults);
        $finish;
    end
    initial begin #100000;$fatal(1,"LSU_UNIT_FAIL timeout");end
endmodule
