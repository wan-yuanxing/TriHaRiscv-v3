# Windows entry point; Python uses only its installed standard library.
[CmdletBinding()]
param([Parameter(ValueFromRemainingArguments=$true)][string[]] $Options)
python (Join-Path $PSScriptRoot 'run_isa_regression.py') @Options
exit $LASTEXITCODE
