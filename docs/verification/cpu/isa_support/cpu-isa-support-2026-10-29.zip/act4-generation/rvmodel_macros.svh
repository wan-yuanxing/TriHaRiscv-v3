// Auto-generated from rvmodel_macros.h by act (do not edit)
// SPDX-License-Identifier: Apache-2.0

`ifndef _RVMODEL_MACROS_SVH_ACT4_RV32IM_NOC_20261029T055702Z_
`define _RVMODEL_MACROS_SVH_ACT4_RV32IM_NOC_20261029T055702Z_


`endif // _RVMODEL_MACROS_SVH_ACT4_RV32IM_NOC_20261029T055702Z_
