#!/usr/bin/env bash
set -e
source "$HOME/triha-tools/venv/act4/bin/activate"
export GEM_HOME="$HOME/triha-tools/gems"
export BUNDLE_PATH="$HOME/triha-tools/bundle"
export PATH="$HOME/triha-tools/opt/sail-riscv-0.12/bin:$HOME/triha-tools/opt/riscv-gcc-15.2.0-1-alias/bin:$HOME/triha-tools/gems/bin:$PATH"
cd "$HOME/triha-tools/src/riscv-arch-test"
make -j4 CONFIG_FILES=/mnt/d/FPGA/TriHaRiscv-cpu-windows/build/cpu/act4-rv32im-noc-20261029T055702Z/test_config.yaml WORKDIR=/mnt/d/FPGA/TriHaRiscv-cpu-windows/build/cpu/act4-rv32im-noc-20261029T055702Z/generated EXTENSIONS=I,M,Zicsr FAST=True
