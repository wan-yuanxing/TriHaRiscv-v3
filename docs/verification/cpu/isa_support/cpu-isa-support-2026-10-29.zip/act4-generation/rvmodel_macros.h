/*
 * 文件: rvmodel_macros.h
 * 用途: RISC-V架构测试平台适配宏
 * 作者: CICC1002692
 */

#ifndef TRIHA_RVMODEL_MACROS_H
#define TRIHA_RVMODEL_MACROS_H

#define RVMODEL_DATA_SECTION                                      \
  .pushsection .tohost,"aw",@progbits;                            \
  .balign 8; .global tohost; tohost: .dword 0;                    \
  .balign 8; .global fromhost; fromhost: .dword 0;                \
  .popsection

#define STANDARD_SM_SUPPORTED

#define RVMODEL_HALT_PASS                                         \
  li t0, 1;                                                       \
  la t1, tohost;                                                  \
  sw t0, 0(t1);                                                   \
1: j 1b;

#define RVMODEL_HALT_FAIL                                         \
  li t0, 3;                                                       \
  la t1, tohost;                                                  \
  sw t0, 0(t1);                                                   \
1: j 1b;

#define RVMODEL_IO_INIT(_R1, _R2, _R3)
#define RVMODEL_IO_WRITE_STR(_R1, _R2, _R3, _STR_PTR)            \
1:                                                               \
  lbu  _R1, 0(_STR_PTR);                                         \
  beqz _R1, 4f;                                                  \
  li   _R2, 0x10000000;                                          \
2:                                                               \
  lw   _R3, 4(_R2);                                              \
  andi _R3, _R3, 1;                                             \
  beqz _R3, 2b;                                                  \
  sw   _R1, 0(_R2);                                              \
  addi _STR_PTR, _STR_PTR, 1;                                   \
  j 1b;                                                          \
4:

#define RVMODEL_INTERRUPT_LATENCY 10
#define RVMODEL_MTVEC_ALIGN 2
#define RVMODEL_MAX_CYCLES_PER_TIMER_TICK 1
#define RVMODEL_TIMER_INT_SOON_DELAY 100

#define RVMODEL_SET_MEXT_INT(_R1, _R2)
#define RVMODEL_CLR_MEXT_INT(_R1, _R2)
#define RVMODEL_SET_MSW_INT(_R1, _R2)
#define RVMODEL_CLR_MSW_INT(_R1, _R2)
#define RVMODEL_SET_SEXT_INT(_R1, _R2)
#define RVMODEL_CLR_SEXT_INT(_R1, _R2)
#define RVMODEL_SET_SSW_INT(_R1, _R2)
#define RVMODEL_CLR_SSW_INT(_R1, _R2)

#endif
